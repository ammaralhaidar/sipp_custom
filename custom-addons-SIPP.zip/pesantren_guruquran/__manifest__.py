# -*- coding: utf-8 -*-
#    ________  __      ________  _______   ______          _______    _______   ________     __      _____  ___  ___________  _______    _______  _____  ___   
#   /"       )|" \    /"       )/"     "| /    " \        |   __ "\  /"     "| /"       )   /""\    (\"   \|"  \("     _   ")/"      \  /"     "|(\"   \|"  \  
#  (:   \___/ ||  |  (:   \___/(: ______)// ____  \       (. |__) :)(: ______)(:   \___/   /    \   |.\\   \    |)__/  \\__/|:        |(: ______)|.\\   \    | 
#   \___  \   |:  |   \___  \   \/    | /  /    ) :)      |:  ____/  \/    |   \___  \    /' /\  \  |: \.   \\  |   \\_ /   |_____/   ) \/    |  |: \.   \\  | 
#    __/  \\  |.  |    __/  \\  // ___)(: (____/ //       (|  /      // ___)_   __/  \\  //  __'  \ |.  \    \. |   |.  |    //      /  // ___)_ |.  \    \. | 
#   /" \   :) /\  |\  /" \   :)(:  (    \        /       /|__/ \    (:      "| /" \   :)/   /  \\  \|    \    \ |   \:  |   |:  __   \ (:      "||    \    \ | 
#  (_______/ (__\_|_)(_______/  \__/     \"_____/       (_______)    \_______)(_______/(___/    \___)\___|\____\)    \__|   |__|  \___) \_______) \___|\____\) 
#
#

                                                                                                                                                            

{
    'name': "Modul Guru Quran SISFO Pesantren",

    'summary': """
        Aplikasi SISFO Pesantren
        - Modul Guru untuk SISFO Pesantren""",

    'description': """
        Aplikasi SISFO Pesantren memiliki fitur-fitur sebagai berikut :
        ===============================================================
        * Modul Base / Dasar
        * Modul Akademik
        * Modul Musyrif
        * Modul Guru
        * Modul Orang Tua
        * Modul Kesantrian

        Developed by : 
        - Imam Masyhuri
        - Supriono

        Maret 2022

        Informasi Lebih lanjut, hubungi :
            PT. Cendana Teknika Utama 
            - Ruko Permata Griyashanta NR 24-25 
              Jl Soekarno Hatta - Malang
    """,

    'author': "PT. Cendana Teknika Utama",
    'website': "https://www.cendana2000.co.id",
    'category': 'Education',
    'version': '16.0.1',
    'license': 'OPL-1',

    # any module necessary for this one to work correctly
    'depends': ['base','pesantren_base','pesantren_keuangan'],

    # always loaded
    'data': [
        'security/groups.xml',
        'security/ir.model.access.csv',
        # data
        'views/menu.xml',
        'data/ks_guruquran_data.xml',
        # wizard
        'wizard/res_partner_change_pin.xml',
        # views
        'views/cek_santri.xml',
        'views/guru_quran.xml',
        # 'views/perijinan.xml',
        'views/absen_tahfidz.xml',
        'views/tahfidz_quran.xml',
        'views/absen_tahsin.xml',
        'views/tahsin_quran.xml',
        # 'views/mutabaah_harian.xml',
        'views/pelanggaran.xml',
        'views/kesehatan.xml',
        'views/prestasi_siswa.xml',
        'views/uang_saku.xml',
        'views/pos_wallet_transaction.xml'
        

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    "installable": True,
	"auto_install": False,
	"application": True,  
}
