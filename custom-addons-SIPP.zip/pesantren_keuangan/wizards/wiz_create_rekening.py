from odoo import api, fields, models
from odoo.exceptions import UserError, ValidationError

class RekeningTabungan(models.TransientModel):
    _name = 'wiz.create.rekening'
    _description = 'Create Rekening Tabungan'

    jns_tabungan_id = fields.Many2one('cdn.jenis_tabungan', string='Jenis Tabungan', required=True)
    kode_tabungan   = fields.Char(string='Kode Tabungan', related='jns_tabungan_id.kode')
    tipe_tabungan   = fields.Selection(string='Tipe Tabungan', related='jns_tabungan_id.tipe_tabungan')
    rek_siswa_ids   = fields.Many2many('cdn.siswa', string='Rekening Siswa')
    rek_guru_ids    = fields.Many2many('hr.employee', string='Rekening Guru')

    def action_post(self):
        # if jns_tabungan_id = tabungan_santri or tabungan_ortu then 
        # create cdn.rekening_tabungan for each rek_siswa_ids
        if self.jns_tabungan_id.tipe_tabungan == 'tabungan_santri' or self.jns_tabungan_id.tipe_tabungan == 'tabungan_ortu':
            for rek_siswa in self.rek_siswa_ids:
                #  first check if already exist
                existing_rek_siswa = self.env['cdn.rekening_tabungan'].search([
                    ('jns_tabungan_id', '=', self.jns_tabungan_id.id),
                    ('siswa_id', '=', rek_siswa.id),
                    ('nis', '=', rek_siswa.nis),
                ], limit=1)
                if existing_rek_siswa:
                    continue

                rek_siswa_vals = {
                    'jns_tabungan_id': self.jns_tabungan_id.id,
                    'kode_tabungan': self.kode_tabungan,
                    'tipe_tabungan': self.tipe_tabungan,
                    'partner_id': rek_siswa.partner_id.id,
                    'siswa_id': rek_siswa.id,
                    'nis': rek_siswa.nis,
                }
                #  try create cdn.rekening_tabungan otherwise skip
                try:
                    self.env['cdn.rekening_tabungan'].create(rek_siswa_vals)
                except:
                    # skip if already exist
                    continue

        elif self.jns_tabungan_id.tipe_tabungan == 'tabungan_guru':
            for rek_guru in self.rek_guru_ids:
                #  first check if already exist
                existing_rek_guru = self.env['cdn.rekening_tabungan'].search([
                    ('jns_tabungan_id', '=', self.jns_tabungan_id.id),
                    ('employee_id', '=', rek_guru.id),
                    ('nip', '=', rek_guru.nip),
                ], limit=1)
                if existing_rek_guru:
                    continue

                rek_guru_vals = {
                    'jns_tabungan_id': self.jns_tabungan_id.id,
                    'kode_tabungan': self.kode_tabungan,
                    'tipe_tabungan': self.tipe_tabungan,
                    'employee_id': rek_guru.id,
                    'nip': rek_guru.nip,
                    'partner_id': rek_guru.user_id.partner_id.id,
                }
                #  try create cdn.rekening_tabungan otherwise skip
                try:
                    self.env['cdn.rekening_tabungan'].create(rek_guru_vals)
                except:
                    pass
        else:
            raise UserError('Tipe Tabungan tidak diketahui !')

        

        # return list cdn.rekening_tabungan
        return {
            'name': 'Rekening Tabungan',
            'view_mode': 'tree,form',
            'res_model': 'cdn.rekening_tabungan',
            'type': 'ir.actions.act_window',
            'target': 'current',
            # 'context': {'default_jns_tabungan_id': self.jns_tabungan_id.id},
            # 'domain': [('jns_tabungan_id', '=', self.jns_tabungan_id.id)]
        }

