from odoo import api, fields, models
from odoo.exceptions import UserError, Warning, ValidationError

class TabunganWallet(models.TransientModel):
    _name = 'wiz.tabungan.wallet'
    _description = 'Create Tabungan Wallet'

    jns_tabungan_id  = fields.Many2one('cdn.jenis_tabungan', string='Jenis Tabungan')
    tipe_tabungan   = fields.Selection(string='Tipe Tabungan', related='jns_tabungan_id.tipe_tabungan', store=True)
    rekening_id     = fields.Many2one('cdn.rekening_tabungan', string='Rekening Tabungan')
    siswa_id        = fields.Many2one(comodel_name='cdn.siswa', string='Siswa', required=True)
    pin_siswa       = fields.Char(string='PIN', related='siswa_id.wallet_pin', readonly=True)
    pin_input       = fields.Char(string='PIN')
    partner_id      = fields.Many2one(comodel_name='res.partner', string='Partner', readonly=True)
    saldo_awal_wallet = fields.Float(string='Saldo Awal Dompet', related='siswa_id.wallet_balance', readonly=True)
    saldo_akhir_wallet = fields.Float(string='Saldo Akhir Dompet', compute='_compute_saldo_akhir_wallet')
    amount_out      = fields.Float(string='Tabungan', required=True)
    saldo_tabungan  = fields.Float(string='Saldo Tabungan', readonly=True)

    @api.onchange('siswa_id')
    def _onchange_siswa_id(self):
        if self.siswa_id:
            self.partner_id = self.siswa_id.partner_id.id

            # Cari data rekening dengan tipe_tabungan = tabungan_santri
            jns_tabungan_id = self.env['cdn.jenis_tabungan'].search([('tipe_tabungan', '=', 'tabungan_santri')])
            if jns_tabungan_id:
                self.jns_tabungan_id = jns_tabungan_id[0]
                self.rekening_id = self.env['cdn.rekening_tabungan'].search([('jns_tabungan_id', '=', self.jns_tabungan_id.id), ('siswa_id', '=', self.siswa_id.id)])
                if not self.rekening_id:
                    raise UserError('Rekening Tabungan tidak ditemukan !')
                
            self.saldo_tabungan = self.rekening_id.saldo_tabungan
                    
                
                    

    @api.depends('siswa_id.wallet_balance', 'amount_out')
    def _compute_saldo_akhir_wallet(self):
        for rec in self:
            rec.saldo_akhir_wallet = rec.siswa_id.wallet_balance - rec.amount_out

    def action_post(self):
        # Chek if amount_out is less than zero and greater than saldo_awal_wallet
        if self.amount_out < 0:
            raise UserError('Nilai tabungan tidak boleh kurang dari 0.')
        if self.amount_out > self.saldo_awal_wallet:
            raise UserError('Nilai tabungan tidak boleh lebih besar dari saldo awal dompet.')
        
        # Cek PIN
        if self.pin_input != self.pin_siswa:
            raise UserError('Maaf.. PIN tidak sesuai !')
        
        # Insert new record di pos.wallet.transaction
        PosWalletTransaction = self.env['pos.wallet.transaction'].sudo().create({
            'wallet_type'       : 'debit',
            'reference'         : 'tabungan',
            'amount'            : self.amount_out,
            'partner_id'        : self.partner_id.id,
            'currency_id'       : self.partner_id.property_product_pricelist.currency_id.id,
        })
        
        
        # Update wallet balance di partner setelah diambil utk Tabungan
        Partner = self.env['res.partner'].sudo().browse(self.partner_id.id)
        Partner.write({'wallet_balance': Partner.calculate_wallet() })
        
        # Insert new record di cdn.tabungan
        Tabungan = self.env['cdn.tabungan']
        Tabungan.create({
            'rekening_id'       : self.rekening_id.id,
            'tgl_transaksi'     : fields.Datetime.now(),
            'siswa_id'          : self.siswa_id.id,
            'jns_tabungan_id'   : self.jns_tabungan_id.id,
            'tipe_tabungan'     : self.tipe_tabungan,
            'partner_id'        : self.partner_id.id,
            'jns_transaksi'     : 'masuk',
            'saldo_awal'        : self.rekening_id.saldo_tabungan,
            'amount_in'         : self.amount_out,
            'amount_out'        : 0,
            'validasi_id'       : self.env.user.id,
            'validasi_time'     : fields.Datetime.now(),
            'keterangan'        : 'Transaksi Wallet '+ PosWalletTransaction.name if PosWalletTransaction.name else 'Transaksi Wallet',
            'state'             : 'confirm',
        })
