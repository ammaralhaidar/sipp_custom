from odoo import api, fields, models


class PenetapanTagihan(models.TransientModel):
    _inherit = 'generate.invoice'

    
