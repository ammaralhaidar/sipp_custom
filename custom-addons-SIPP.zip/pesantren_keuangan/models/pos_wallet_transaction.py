from odoo import api, fields, models

class PosWalletTransaction(models.Model):
    _inherit        = 'pos.wallet.transaction'

    # add selection for reference
    reference = fields.Selection([
		('manual', 'Manual'),
		('pos_order', 'POS Order'),
        ('tabungan', 'Tabungan'),
		], string='Reference', default='manual')