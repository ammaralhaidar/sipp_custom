from odoo import models, fields, api, _
from odoo.exceptions import UserError, Warning, ValidationError
import json

class JenisTabungan(models.Model):
    _name               = "cdn.jenis_tabungan"
    _description        = "Jenis Tabungan"

    name            = fields.Char(string='Nama Tabungan', required=True)
    kode            = fields.Char(string='Kode Tabungan', required=True)
    tipe_tabungan   = fields.Selection(string='Tipe Tabungan', selection=[
                        ('tabungan_santri', 'Tabungan Santri'),
                        ('tabungan_ortu', 'Tabungan Ortu'),
                        ('tabungan_guru', 'Tabungan Guru'),
                    ], required=True)
    # sumber tabungan : uang saku atau dompet santri
    sumber_tabungan = fields.Selection(string='Sumber Tabungan', selection=[
                        ('uang_saku', 'Uang Saku'),
                        ('dompet_santri', 'Dompet Santri'),
                        ('lainnya', 'Lainnya'),
                    ], required=True)
    target_tabungan = fields.Float(string='Target Tabungan', default=0)
    prefix_va       = fields.Char(string='Prefix', size=6)
    keterangan      = fields.Text(string='Keterangan')

    #constraints : kode tabungan berisi 2 karakter numerik
    @api.constrains('kode')
    def _check_kode(self):
        for rec in self:
            if len(rec.kode) != 2:
                raise ValidationError('Kode tabungan harus berisi 2 karakter numerik !')
            if not rec.kode.isdigit():
                raise ValidationError('Kode tabungan harus berisi 2 karakter numerik !')
    # constraints : prefix berisi 6 karakter numerik
    @api.constrains('prefix_va')
    def _check_prefix_va(self):
        for rec in self:
            if len(rec.prefix_va) != 6:
                raise ValidationError('Prefix harus berisi 6 karakter numerik !')
            if not rec.prefix_va.isdigit():
                raise ValidationError('Prefix harus berisi 6 karakter numerik !')
            
            

    _sql_constraints    = [('kode_tabungan_uniq', 'unique(kode)', 'Kode tabungan sudah pernah terdaftar, pastikan kode tabungan unik !')]

class RekeningTabungan(models.Model):
    _name               = "cdn.rekening_tabungan"
    _description        = "Rekening Tabungan"
    _inherit            = ['mail.thread', 'mail.activity.mixin']

    name                = fields.Char(string='No Rekening', required=True, default='New', tracking=True)
    jns_tabungan_id     = fields.Many2one('cdn.jenis_tabungan', string='Jenis Tabungan', required=True, tracking=True)
    kode_tabungan       = fields.Char(string='Kode Tabungan', related='jns_tabungan_id.kode')
    tipe_tabungan       = fields.Selection(string='Tipe Tabungan', related='jns_tabungan_id.tipe_tabungan', store=True)
    sumber_tabungan     = fields.Selection(string='Sumber Tabungan', related='jns_tabungan_id.sumber_tabungan')
    partner_id          = fields.Many2one(comodel_name='res.partner', string='Partner', required=True, tracking=True)
    siswa_id            = fields.Many2one(comodel_name='cdn.siswa', string='Siswa', tracking=True)
    orangtua_id         = fields.Many2one(comodel_name='cdn.orangtua', string='Ortu', related='siswa_id.orangtua_id')
    ruangkelas_id       = fields.Many2one(comodel_name='cdn.ruang_kelas', string='Ruang Kelas', related='siswa_id.ruang_kelas_id', store=True)
    employee_id         = fields.Many2one(comodel_name='hr.employee', string='Guru/Karyawan', tracking=True)
    nis                 = fields.Char(string="No Induk Siswa", related='siswa_id.nis')
    nip                 = fields.Char(string="No Pegawai", related='employee_id.nip')

    no_va               = fields.Char(string='Virtual Account', tracking=True)
    saldo_tabungan      = fields.Float(string='Saldo Tabungan', compute='_compute_saldo_tabungan', store=True, tracking=True)
    tabungan_lines      = fields.One2many(comodel_name='cdn.tabungan', inverse_name='rekening_id', string='Tabungan', tracking=True)
    state               = fields.Selection(string='Status', selection=[('draft', 'Draft'), ('done', 'Read Only')], default='draft', readonly=True, tracking=True)

    # _sql_constraints    = [('no_rekening_tab_uniq', 'unique(name)', 'No Rekening Tabungan sudah pernah terdaftar, pastikan No Rekening Tabungan unik !')]

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            # jika siswa : name = nis +'-'+kode_tabungan
            # jika guru : name = nip +'-'+kode_tabungan
            if vals.get('siswa_id', False) and vals.get('jns_tabungan_id', False):
                Siswa = self.env['cdn.siswa'].search([('id','=',vals['siswa_id'])])
                print(Siswa.nis)
                JenisTabungan = self.env['cdn.jenis_tabungan'].search([('id','=',vals['jns_tabungan_id'])])
                print(JenisTabungan.kode)
                vals['name'] = Siswa.nis + '-' + JenisTabungan.kode
                vals['no_va'] = JenisTabungan.prefix_va + Siswa.nis if JenisTabungan.prefix_va else False
            elif vals.get('employee_id', False) and vals.get('jns_tabungan_id', False):
                Employee = self.env['hr.employee'].search([('id','=',vals['employee_id'])])
                JenisTabungan = self.env['cdn.jenis_tabungan'].search([('id','=',vals['jns_tabungan_id'])])
                vals['name'] = Employee.nip + '-' + JenisTabungan.kode
            else: #raise ValidationError('No siswa_id or employee_id')
                raise UserError('NIS atau NIP tidak ditemukan !')
        return super(RekeningTabungan, self).create(vals)

    # compute saldo tabungan from tabungan lines for each rekening and jns_tabungan_id
    @api.depends('tabungan_lines')
    def _compute_saldo_tabungan(self):
        for rekening in self:
            rekening.saldo_tabungan = sum(rekening.mapped('tabungan_lines.amount_in')) - sum(rekening.mapped('tabungan_lines.amount_out')) 

    # name_get No_rekening - Nama Rekening
    def name_get(self):
        result = []
        for record in self:
            # jika tabungan_siswa dan tabungan_ortu : name berisi No rekening dan nama siswa
            if record.tipe_tabungan == 'tabungan_ortu' or record.tipe_tabungan == 'tabungan_santri':
                result.append((record.id, '{} - {}'.format(record.name, record.siswa_id.name)))
                # jika tabungan_guru : name berisi No rekening dan nama guru
            elif record.tipe_tabungan == 'tabungan_guru':
                result.append((record.id, '{} - {}'.format(record.name, record.employee_id.name)))
            else:
                result.append((record.id, record.name))
        return result
    
    def action_draft(self):
        self.state = 'draft'

    def action_done(self):
        # Chek no rekening tabungan sudah pernah terdaftar
        if self.name != 'New':
            existing_tabungan = self.env['cdn.tabungan'].search([
                ('name', '=', self.name),
                ('state', '!=', 'draft')
            ], limit=1)
            if existing_tabungan:
                raise UserError("No Rekening Tabungan sudah pernah terdaftar, pastikan No Rekening Tabungan unik !")
            
            # Update name = nis +'-'+kode_tabungan untuk tabungan_santri dan tabungan_ortu
            if self.tipe_tabungan == 'tabungan_ortu' or self.tipe_tabungan == 'tabungan_santri':
                self.name = self.siswa_id.nis + '-' + self.jns_tabungan_id.kode
            elif self.tipe_tabungan == 'tabungan_guru':
                self.name = self.employee_id.nip + '-' + self.jns_tabungan_id.kode
        
            self.state = 'done'

    @api.onchange('siswa_id')
    def _onchange_siswa_id(self):
        if self.siswa_id:
            self.partner_id = self.siswa_id.partner_id

    @api.onchange('employee_id')
    def _onchange_employee_id(self):
        if self.employee_id:
            self.partner_id = self.employee_id.user_id.partner_id
        #
        
    def lock_all_rekening_tabungan(self):
        for rekening in self:
            #  set state to 'done'
            rekening.state = 'done'
    
    def unlock_all_rekening_tabungan(self):
        for rekening in self:
            #  set state to 'draft'
            rekening.state = 'draft'
           

    

class Tabungan(models.Model):
    _name               = "cdn.tabungan"
    _description        = "Tabungan"
    _order              = 'tgl_transaksi desc'
    _inherit            = ['mail.thread', 'mail.activity.mixin']

    name            = fields.Char(string='No Referensi', readonly=True)
    tgl_transaksi   = fields.Datetime(string='Tanggal Transaksi', required=True, default=fields.Datetime.now)
    rekening_id     = fields.Many2one('cdn.rekening_tabungan', string='Rekening Tabungan', required=True)
    jns_tabungan_id  = fields.Many2one('cdn.jenis_tabungan', string='Jenis Tabungan', required=True)
    tipe_tabungan   = fields.Selection(string='Tipe Tabungan', related='jns_tabungan_id.tipe_tabungan', store=True)
    partner_id      = fields.Many2one(comodel_name='res.partner', readonly=True)
    siswa_id        = fields.Many2one(comodel_name='cdn.siswa', string='Siswa',readonly=True)
    va_saku         = fields.Char(string='No. VA Saku', readonly=True, store=True)
    saldo_awal      = fields.Float(string='Saldo Awal', readonly=True)
    saldo_akhir     = fields.Float(string='Saldo Akhir', readonly=True, store=True, compute='_compute_saldo_akhir')

    jns_transaksi   = fields.Selection(string='Jenis Transaksi', selection=[
        ('masuk', 'Uang Masuk'),
        ('keluar', 'Uang Keluar'),
    ], required=True, default='masuk')
    amount_in       = fields.Float(string='Nominal Masuk')
    amount_out      = fields.Float(string='Nominal Keluar')

    validasi_id     = fields.Many2one(comodel_name='res.users', string='Validasi', readonly=True)
    validasi_time   = fields.Datetime(string='Tanggal Validasi', readonly=True)
    keterangan      = fields.Text(string='Keterangan')

    state           = fields.Selection(string='State', selection=[
        ('draft', 'Draft'),
        ('confirm', 'Confirm'),
    ], default='draft', readonly=True)

    # override
    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('cdn.tabungan') or 'New'
        result = super(Tabungan, self).create(vals)
        return result
    
    @api.onchange('rekening_id')
    def _onchange_rekening_id(self):
        if self.rekening_id:
            self.partner_id = self.rekening_id.partner_id
            self.siswa_id = self.rekening_id.siswa_id
            self.saldo_awal = self.rekening_id.saldo_tabungan

    # actions
    def action_confirm(self):
        # Check if amount_in is greater than zero
        if self.jns_transaksi == 'masuk' and self.amount_in < 0:
            raise UserError('Nilai masuk tidak boleh kurang atau sama dengan 0.')
        # Check if amount_out is greater than zero, and less than saldo_awal
        if self.jns_transaksi == 'keluar' and self.amount_out < 0:
            raise UserError('Nilai keluar tidak boleh kurang atau sama dengan 0.')
        
        for rec in self:
            rec.state = 'confirm'
            rec.validasi_id = self.env.user.id
            rec.validasi_time = fields.Datetime.now()
            # rec.siswa_id.write({
            #     'saldo_uang_saku': rec.siswa_id.calculate_saku(),
            # })

    # onchange amount_in must be greater than zero
    @api.onchange('amount_in')
    def _onchange_amount_in(self):
        if self.amount_in < 0:
            raise UserError('Nilai masuk tidak boleh kurang atau sama dengan 0.')
        
    # onchange amount_out must be greater than zero, and less than saldo_awal
    @api.onchange('amount_out')
    def _onchange_amount_out(self):
        if self.amount_out < 0:
            raise UserError('Nilai keluar tidak boleh kurang atau sama dengan 0.')
        if self.amount_out > self.saldo_awal:
            raise UserError('Nilai keluar tidak boleh lebih besar dari saldo awal.')

    # onchange tipe_tabungan
    # @api.onchange('tipe_tabungan')
    # def _onchange_tipe_tabungan(self):
    #     if self.tipe_tabungan == 'tabungan_ortu':
    #         return {'domain': {'partner_id': [('jns_partner', '=', 'siswa')]}}
    #     elif self.tipe_tabungan == 'tabungan_guru':
    #         return {'domain': {'partner_id': [('jns_partner', '=', 'guru')]}}
    #     else:
    #         return {'domain': {'partner_id': []}}
        

    # @api.depends('partner_id')
    # def _compute_siswa(self):
    #     for record in self:
    #         Siswa = self.env['cdn.siswa'].search([('partner_id','=',record.partner_id.id)]) # siswa_id is partner_id
    #         if Siswa:
    #             record.siswa = Siswa[0].id
    #         else:
    #             record.siswa = False

    # @api.depends('rekening_id')
    # def _compute_saldo_awal(self):
    #     for record in self:
    #         if record.rekening_id:
    #             record.saldo_awal = record.rekening_id.saldo_tabungan
            

    @api.depends('saldo_awal', 'amount_in', 'amount_out')
    def _compute_saldo_akhir(self):
        for record in self:
            record.saldo_akhir = record.saldo_awal + record.amount_in - record.amount_out

    

    