from odoo import models, fields, api, _
from odoo.exceptions import UserError, Warning

#inherit hr.employee add last_tahfidz many2one to cdn.tahfidz_musyrif
class Employee(models.Model):
    _inherit = 'hr.employee'

    last_tahfidz = fields.Many2one('cdn.tahfidz_musyrif', string='Tahfidz Terakhir', readonly=True)

class TahfidzMusyrif(models.Model):
    _name               = "cdn.tahfidz_musyrif"
    _description        = "Tabel Data Tahfidz Musyrif"
    _inherit            = ['mail.thread', 'mail.activity.mixin']

    name            = fields.Char(string='No Referensi', readonly=True)
    tanggal         = fields.Date(string='Tanggal', required=True, default=fields.Date.context_today)
    musyrif_id      = fields.Many2one('hr.employee', string='Musyrif', required=True)
    last_tahfidz    = fields.Many2one('cdn.tahfidz_musyrif', string='Tahfidz Terakhir', related='musyrif_id.last_tahfidz', readonly=True, store=True)
    ustadz_id       = fields.Many2one('hr.employee', string='Ustadz')
    sesi_tahfidz_id = fields.Many2one('cdn.sesi_tahfidz', string='Sesi', required=True)
    
    # first surah
    # def _get_surah_id(self):
    #     if self.last_tahfidz:
    #         if not self.last_tahfidz.surah_id.number == 114 and self.last_tahfidz.ayat_akhir.name == self.last_tahfidz.surah_id.jml_ayat:
    #             surah = self.env['cdn.surah'].search([('number', '>', self.last_tahfidz.surah_id.number)], limit=1).id
    #             ayat_awal = self.env['cdn.ayat'].search([('surah_id', '=', self.last_tahfidz.surah_id.id)], limit=1).id
    #         else:
    #             # if last_tahfidz.surah_id not equal to last_tahfidz.surah2_id then set surah to last_tahfidz.surah2_id
    #             if self.last_tahfidz.surah_id != self.last_tahfidz.surah2_id:
    #                 surah = self.last_tahfidz.surah2_id.id
    #                 # ayat awal to first ayat of surah
    #                 ayat_awal = self.last_tahfidz.surah2_id.ayat_ids and self.last_tahfidz.surah2_id.ayat_ids[0].id or False
    #             else:
    #                 # still on same surah, set surah to last_tahfidz.surah_id
    #                 # and ayat_awal to last_tahfidz.ayat_akhir + 1
    #                 surah = self.last_tahfidz.surah_id.id
    #                 ayat_awal = self.last_tahfidz.ayat_akhir.id + 1
    #         return surah
    #     else:
    #         return False
        
    surah_id        = fields.Many2one('cdn.surah', string='Surah', states={'done': [('readonly', True)]})
    number          = fields.Integer(string='Surah Ke', related='surah_id.number', readonly=True)
    jml_ayat        = fields.Integer(string='Jumlah Ayat', related='surah_id.jml_ayat', readonly=True, store=True)
    ayat_awal       = fields.Many2one('cdn.ayat', string='Ayat Awal', states={'done': [('readonly', True)]})
    page_awal       = fields.Integer(string='Halaman Awal', related='ayat_awal.page', readonly=True)
    ayat_awal_name  = fields.Integer(string='Ayat Awal', related='ayat_awal.name', readonly=True)

    # last surah - maybe same as first surah
    is_change_surah = fields.Boolean(string='Ganti Surah', default=False, states={'done': [('readonly', True)]})
    surah2_id       = fields.Many2one('cdn.surah', string='Surah Akhir', states={'done': [('readonly', True)]})
    number2         = fields.Integer(string='Surah Akhir Ke', related='surah2_id.number', readonly=True)
    
    ayat_akhir      = fields.Many2one('cdn.ayat', string='Ayat Akhir', states={'done': [('readonly', True)]})
    page_akhir      = fields.Integer(string='Halaman Akhir', related='ayat_akhir.page', readonly=True)
    jml_baris       = fields.Integer(string='Jumlah Baris', states={'done': [('readonly', True)]})
    nilai_id        = fields.Many2one('cdn.nilai_tahfidz', string='Nilai', states={'done': [('readonly', True)]})
    keterangan      = fields.Char(string='Keterangan', states={'done': [('readonly', True)]})
    state           = fields.Selection([('draft', 'Draft'),('done', 'Done')], default='draft', string='Status')

    #onchange musyrif_id
    @api.onchange('musyrif_id')
    def _onchange_musyrif_id(self):
        if self.musyrif_id:
            if self.musyrif_id.last_tahfidz:
                if not self.musyrif_id.last_tahfidz.surah_id.number == 114 and self.musyrif_id.last_tahfidz.ayat_akhir.name == self.musyrif_id.last_tahfidz.surah_id.jml_ayat:
                    self.surah_id = self.env['cdn.surah'].search([('number', '>', self.musyrif_id.last_tahfidz.surah_id.number)], limit=1).id
                    self.ayat_awal = self.env['cdn.ayat'].search([('surah_id', '=', self.musyrif_id.last_tahfidz.surah_id.id)], limit=1).id
                else:
                    # if last_tahfidz.surah_id not equal to last_tahfidz.surah2_id then set surah to last_tahfidz.surah2_id
                    if self.musyrif_id.last_tahfidz.surah_id != self.musyrif_id.last_tahfidz.surah2_id:
                        self.surah_id = self.musyrif_id.last_tahfidz.surah2_id.id
                        # ayat awal to first ayat of surah
                        self.ayat_awal = self.musyrif_id.last_tahfidz.surah2_id.ayat_ids and self.musyrif_id.last_tahfidz.surah2_id.ayat_ids[0].id or False
                    else:
                        # still on same surah, set surah to last_tahfidz.surah_id
                        # and ayat_awal to last_tahfidz.ayat_akhir + 1
                        self.surah_id = self.musyrif_id.last_tahfidz.surah_id.id
                        self.ayat_awal = self.musyrif_id.last_tahfidz.ayat_akhir.id + 1

                self.surah2_id = self.musyrif_id.last_tahfidz.surah2_id.id if self.musyrif_id.last_tahfidz.surah2_id else self.musyrif_id.last_tahfidz.surah_id.id
            else:
                self.surah_id = False
                self.ayat_awal = False
                self.surah2_id = False
                self.ayat_akhir = False
            

    @api.model
    def create(self, vals):
        vals['name'] = self.env['ir.sequence'].next_by_code('cdn.tahfidz_musyrif')
        return super(TahfidzMusyrif, self).create(vals)

    #onchange surah_id
    @api.onchange('surah_id')
    def _onchange_surah_id(self):
        if self.surah_id and not self.surah2_id:
            # If surah_id is set, set surah2_id to the same surah
            self.surah2_id = self.surah_id
    
    #onchange is_change_surah
    @api.onchange('is_change_surah')
    def _onchange_is_change_surah(self):
        if self.is_change_surah:
            # If is_change_surah is True, set surah2_id to next surah
            next_surah = self.env['cdn.surah'].search([
                ('number', '>', self.surah_id.number)
            ], limit=1)
            if next_surah:
                self.surah2_id = next_surah
                # self.ayat_akhir = first ayat of next surah
                self.ayat_akhir = next_surah.ayat_ids and next_surah.ayat_ids[0] or False
        else:
            # If is_change_surah is False, surah2_id should be same as surah_id
            self.surah2_id = self.surah_id
            self.ayat_akhir = self.ayat_awal


    def get_last_tahfidz(self):
        last_tahfidz = self.env['cdn.tahfidz_musyrif'].search([
            ('musyrif_id', '=', self.musyrif_id.id),
            ('state', '=', 'done'),
        ], order='id desc', limit=1)
        return last_tahfidz
    
    def action_confirm(self):
        # Verify if ayat_akhir is greater than ayat_awal 
        if self.ayat_akhir and self.ayat_awal and self.ayat_akhir.name < self.ayat_awal.name:
            if self.surah2_id == self.surah_id:
                raise UserError("Ayat Akhir harus lebih besar dari Ayat Awal pada Surah yang sama.")
            
        
        self.state = 'done'
        self.musyrif_id.last_tahfidz = self.get_last_tahfidz()

    def action_draft(self):
        self.state = 'draft'
        self.musyrif_id.last_tahfidz = self.get_last_tahfidz()

    @api.onchange('ayat_awal')
    def _onchange_ayat_awal(self):
        return {
            'value': {'ayat_akhir': False}
        }
    
    def name_get(self):
        result = []
        for record in self:
            if record.state == 'draft':
                result.append((record.id, record.name))
            else:
                if record.surah2_id == record.surah_id:
                    result.append((
                        record.id, 
                        '{} # ayat {} - {} # {} baris # {}'.format(
                            record.surah_id.display_name, 
                            record.ayat_awal.name, 
                            record.ayat_akhir.name, 
                            record.jml_baris, 
                            record.nilai_id.name
                        )
                    ))
                else:
                    # If surah2_id is different from surah_id, show both surahs
                    # Surah 1 # Ayat Awal - Surah 2 # Ayat Akhir # Jumlah Baris # Nilai
                    result.append((
                        record.id, 
                        '{} ayat {} - {} ayat {} # {} baris # {}'.format(
                            record.surah_id.display_name, 
                            record.ayat_awal.name, 
                            record.surah2_id.display_name or record.surah_id.display_name,
                            record.ayat_akhir.name, 
                            record.jml_baris, 
                            record.nilai_id.name
                        )
                    ))
                
        return result
