# from odoo import api, fields, models


# class ResPartner(models.Model):
#     _inherit = 'res.partner'
    
#     name = fields.Char(string='Nama', required=True)
