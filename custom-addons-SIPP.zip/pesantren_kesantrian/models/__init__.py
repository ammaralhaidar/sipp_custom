# -*- coding: utf-8 -*-
from . import kesehatan
from . import cdn_surah,cdn_ayat
from . import tindakan_hukuman, sesi_tahfidz , jns_pelanggaran, data_pelanggaran, halaqoh,level_tahsin, daftar_hadits, nilai_tahfidz
from . import mutabaah, mutabaah_harian
from . import aset_pesantren
from . import kamar_santri
from . import pelanggaran
from . import santri
from . import jns_prestasi, prestasi_siswa
from . import guru
from . import orangtua
from . import perijinan
from . import absen_tahfidz
from . import tahfidz_hadits
from . import res_partner
from . import tahfidz_quran
from . import absen_tahsin
from . import tahsin_quran
from . import res_users
from . import tahfidz_musyrif