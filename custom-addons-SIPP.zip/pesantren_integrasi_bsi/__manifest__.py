# -*- coding: utf-8 -*-
#
#
#        $$$$$$\                            $$\                                $$$$$$\   $$$$$$\   $$$$$$\   $$$$$$\  
#       $$  __$$\                           $$ |                              $$  __$$\ $$$ __$$\ $$$ __$$\ $$$ __$$\ 
#       $$ /  \__| $$$$$$\  $$$$$$$\   $$$$$$$ | $$$$$$\  $$$$$$$\   $$$$$$\  \__/  $$ |$$$$\ $$ |$$$$\ $$ |$$$$\ $$ |
#       $$ |      $$  __$$\ $$  __$$\ $$  __$$ | \____$$\ $$  __$$\  \____$$\  $$$$$$  |$$\$$\$$ |$$\$$\$$ |$$\$$\$$ |
#       $$ |      $$$$$$$$ |$$ |  $$ |$$ /  $$ | $$$$$$$ |$$ |  $$ | $$$$$$$ |$$  ____/ $$ \$$$$ |$$ \$$$$ |$$ \$$$$ |
#       $$ |  $$\ $$   ____|$$ |  $$ |$$ |  $$ |$$  __$$ |$$ |  $$ |$$  __$$ |$$ |      $$ |\$$$ |$$ |\$$$ |$$ |\$$$ |
#       \$$$$$$  |\$$$$$$$\ $$ |  $$ |\$$$$$$$ |\$$$$$$$ |$$ |  $$ |\$$$$$$$ |$$$$$$$$\ \$$$$$$  /\$$$$$$  /\$$$$$$  /
#        \______/  \_______|\__|  \__| \_______| \_______|\__|  \__| \_______|\________| \______/  \______/  \______/ 
# 
#
 
{
    'name': "Modul Integrasi BSI",

    'summary': """
        Modul Integrasi BSI untuk SISFO Pesantren""",

    'description': """
        Aplikasi SISFO Pesantren memiliki fitur-fitur sebagai berikut :
        ===============================================================
        * Modul Base / Dasar
        * Modul Akademik
        * Modul Keuangan
        * Modul Guru
        * Modul Orang Tua
        * Modul Kesantrian

        Developed by : 
        - Imam Masyhuri
        - Supriono

        Maret 2022

        Informasi Lebih lanjut, hubungi :
            PT. Cendana Teknika Utama 
            - Ruko Permata Griyashanta NR 24-25 
              Jl Soekarno Hatta - Malang
    """,

    'author'    : "PT. Cendana Teknika Utama",
    'website'   : "https://www.cendana2000.co.id",
    'category'  : 'Education',
    'version'   : '16.0.1',
    'license'   : 'OPL-1',

    # any module necessary for this one to work correctly
    'depends'       : [
        'pesantren_base',
        'pesantren_keuangan'
    ],

    # always loaded
    'data'          : [
        # securities
        'security/groups.xml',
        'security/ir.model.access.csv',

        # data
        'data/data.xml',

        # menus
        'views/menu.xml',

        # views
        'views/inherit_account_move.xml',
        'views/log_api_bsi.xml',
        'views/res_config_settings.xml',
        'views/inherit_siswa.xml',

        # wizards

        # reports

        # dashboards

    ],

    # only loaded in demonstration mode
    'demo'          : [
        'demo/demo.xml',
    ],
    'application'   : True
}
