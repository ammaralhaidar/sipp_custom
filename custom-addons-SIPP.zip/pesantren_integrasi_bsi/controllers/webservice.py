# -*- coding: utf-8 -*-
from odoo import http
from odoo.http import request, Response
from odoo.loglevels import ustr

from datetime import datetime, timezone
import pytz

from ..tools.integrasi_bsi import *

import json

class Webservice(http.Controller):
    @http.route('/bsi/payment-notification', type='http', auth='public', methods=['POST'], csrf=False, cors='*')
    def payment_notification(self, **kw):
        i_params      = json.loads(request.httprequest.data)
        i_id_tagihan  = i_params.get('idTagihan', '-')
        try:
            i_kode_channel                     = i_params.get('kodeChannel')
            i_tanggal_transaksi                = i_params.get('tanggalTransaksi')
            i_totalNominal                     = i_params.get('totalNominal')
            i_total_fee                        = i_params.get('totalFee')
            i_penanggung_fee                   = i_params.get('penanggungFee')
            i_totalNominal_pembayaran_dan_fee  = i_params.get('totalNominalPembayaranDanFee')
            i_status_validasi                  = i_params.get('statusValidasi')
            i_no_pembayaran                    = i_params.get('nomorPembayaran')
            i_id_pelanggan                     = i_params.get('idPelanggan')

            cek_param = request.env['cdn.log.api.bsi'].sudo().search([('id_tagihan','=',i_id_tagihan)], limit=1)
            if cek_param:
                result = {
                    "status" : "999",
                    "msg"    : "Data dengan ID Tagihan tersebut sudah terkirim sebelumnya"
                }
                save_log(
                    '-', 
                    "POST", 
                    "Payment Notification BSI", 
                    '-', 
                    '-', 
                    json.dumps(i_params, indent=2), 
                    '999',
                    json.dumps(result, indent=2), 
                    i_id_tagihan, 
                )
                return Response(json.dumps(result), headers = {
                    'Content-Type': 'application/json'
                })

            status_response = "999"
            if i_status_validasi == 'Sukses':
                biaya_pengurangan_pembayaran_bsi = request.env['ir.config_parameter'].sudo().get_param('pesantren_integrasi_bsi.bsi_biaya_pemotongan')
                biaya_pengurangan_pembayaran_bsi = float(biaya_pengurangan_pembayaran_bsi)
                if i_no_pembayaran[:2] == '02':
                    siswa = request.env['cdn.siswa'].sudo().search([('va_pengiriman_uang_saku_bsi','=',i_id_pelanggan)], limit=1)
                    if siswa:
                        tanggal_transaksi = i_tanggal_transaksi.split('.')[0]  # hasil: '2025-06-10 10:54:48'
                        payment_datetime = datetime.strptime(tanggal_transaksi, '%Y-%m-%d %H:%M:%S')

                        # payment_date_iso = datetime.fromisoformat(i_tanggal_transaksi)
                        # payment_datetime = datetime.strptime(payment_date_iso.strftime("%Y-%m-%d %H:%M:%S"), '%Y-%m-%d %H:%M:%S')

                        request.env['cdn.riwayat.uang.saku.bsi'].sudo().create({
                            'siswa_id'            : siswa.id,
                            'payment_channel_bsi' : i_kode_channel,
                            'payment_ammount_bsi' : int(i_totalNominal) - int(biaya_pengurangan_pembayaran_bsi),
                            'watktu_dikirim_bsi'  : payment_datetime,
                        })

                        uang_saku = request.env['cdn.uang_saku'].sudo().create({
                            'siswa_id'      : siswa.partner_id.id,
                            'jns_transaksi' : 'masuk',
                            'amount_in'     : int(i_totalNominal) - int(biaya_pengurangan_pembayaran_bsi),
                            'keterangan'    : "Wallet Recharge - BSI",
                        })

                        uang_saku.action_confirm()

                        result = {
                            "status" : "000"
                        }
                        status_response = "000"
                    else:
                        result = {
                            "status" : "999",
                            "msg"    : f"Siswa dengan billing uang saku {i_id_pelanggan} tidak ditemukan"
                        }
                else: 
                    jurnal_pembayaran_bsi = int(request.env['ir.config_parameter'].sudo().get_param('pesantren_integrasi_bsi.bsi_jurnal_id')) or False
                    if jurnal_pembayaran_bsi:
                        siswa = request.env['cdn.siswa'].sudo().search([('va_pengiriman_tagihan_bsi','=',i_id_pelanggan)], limit=1)
                        if siswa:
                            tanggal_transaksi = i_tanggal_transaksi.split('.')[0]  # hasil: '2025-06-10 10:54:48'
                            payment_datetime = datetime.strptime(tanggal_transaksi, '%Y-%m-%d %H:%M:%S')

                            invoice = request.env['account.move'].sudo().search([('partner_id', '=', siswa.partner_id.id), ('state','=','posted'), ('payment_state','in',['not_paid', 'partial']), ('amount_residual', '>', 0)])
                            if len(invoice) > 0:
                                
                                # payment_date_iso = datetime.fromisoformat(i_tanggal_transaksi)
                                # payment_datetime = datetime.strptime(payment_date_iso.strftime("%Y-%m-%d %H:%M:%S"), '%Y-%m-%d %H:%M:%S')
                                
                                # fungsi untuk memanggil proses pembayaran di odoo
                                wizard = request.env['account.payment.register'].with_context(active_model='account.move', active_ids=invoice.ids).sudo().create({
                                    'payment_date': payment_datetime.date(),
                                    'journal_id': jurnal_pembayaran_bsi,
                                    'payment_type': 'inbound',
                                    'group_payment': True,
                                    'amount': int(i_totalNominal) - int(biaya_pengurangan_pembayaran_bsi),
                                })

                                wizard.action_create_payments()


                                memo = ''
                                for inv in invoice:
                                    memo += inv.name+', '

                                # simpan di invoice
                                invoice.write({
                                    'payment_channel_bsi'                           : i_kode_channel,
                                    'payment_ammount_bsi'                           : int(i_totalNominal),
                                    'payment_fee_bsi'                               : i_total_fee,
                                    'payment_penanggung_fee_bsi'                    : i_penanggung_fee,
                                    'payment_total_nominal_pembayaran_dan_fee_bsi'  : i_totalNominal_pembayaran_dan_fee,
                                    'watktu_pembayaran_bsi'                         : payment_datetime,
                                    'status_validasi_bsi'                           : i_status_validasi,
                                    'response'                                      : "Status Validasi : "+i_status_validasi,
                                    'keterangan'                                    : "Pembayaran atas invoice "+memo
                                })

                                request.env['cdn.riwayat.tagihan.bsi'].sudo().create({
                                    'siswa_id'            : siswa.id,
                                    'payment_channel_bsi' : i_kode_channel,
                                    'payment_ammount_bsi' : int(i_totalNominal) - int(biaya_pengurangan_pembayaran_bsi),
                                    'watktu_dikirim_bsi'  : payment_datetime,
                                    'is_valid'            : True,
                                    'keterangan'          : 'Pembayaran Tagihan '+memo,
                                })

                                result = {
                                    "status" : "000"
                                }
                            else:
                                request.env['cdn.riwayat.tagihan.bsi'].sudo().create({
                                    'siswa_id'            : siswa.id,
                                    'payment_channel_bsi' : i_kode_channel,
                                    'payment_ammount_bsi' : int(i_totalNominal) - int(biaya_pengurangan_pembayaran_bsi),
                                    'watktu_dikirim_bsi'  : payment_datetime,
                                    'watktu_dikirim_bsi'  : payment_datetime,
                                    'is_valid'            : False,
                                    'keterangan'          : 'Pembayaran Tidak diketahui',
                                })

                                result = {
                                    "status" : "000"
                                }
                        else:
                            result = {
                                "status" : "999",
                                "msg"    : f"Siswa dengan billing tagihan {i_id_pelanggan} tidak ditemukan"
                            }
                    else:
                        result = {
                            "status" : "999",
                            "msg"    : "Jurnal Pembayaran BSI Tidak Ditemukan"
                        }
                
            else:
                result = {
                    "status" : "999",
                    "msg"    : f"Status Validasi Tidak Sukses"
                }

            save_log(
                '-', 
                "POST", 
                "Payment Notification BSI", 
                '-', 
                '-', 
                json.dumps(i_params, indent=2), 
                status_response,
                json.dumps(result, indent=2), 
                i_id_tagihan, 
            )
            return Response(json.dumps(result), headers = {
                'Content-Type': 'application/json'
            })

        except Exception as err:
            err_traceback = traceback.format_exc()
            result = {
                "status" : "999",
                "msg"    : err_traceback
            }
            save_log(
                '-', 
                "POST", 
                "Payment Notification BSI - Error Code", 
                '-', 
                '-', 
                json.dumps(i_params, indent=2),
                "999",
                json.dumps(result, indent=2),
                i_id_tagihan, 
            )
            return Response(json.dumps(result), headers = {
                    'Content-Type': 'application/json'
                })
