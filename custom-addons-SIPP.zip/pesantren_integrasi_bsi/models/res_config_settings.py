#!/usr/bin/python
#-*- coding: utf-8 -*-
#
#   Fungsi  : Inherit res.config untuk memasukkan data-data konfigurasi 
#  Ditulis oleh : Imam Masyhuri
#  Hak Cipta : © 2023 Cendana2000


from odoo import api, fields, models


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    bsi_jurnal_id        = fields.Many2one('account.journal', string = 'Jurnal Penbayaran Bank BSI', config_parameter='pesantren_integrasi_bsi.bsi_jurnal_id', ondelete = 'cascade')
    bsi_biaya_pemotongan = fields.Float(string='Biaya Pemotongan Pembayaran BSI', config_parameter='pesantren_integrasi_bsi.bsi_biaya_pemotongan')
    
    