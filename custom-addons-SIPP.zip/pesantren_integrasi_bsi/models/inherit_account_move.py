from odoo import api, fields, models

from ..tools.integrasi_bsi import *

from datetime import datetime, date, time
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError


class accountMove(models.Model):
    _inherit = 'account.move'

    tipe_pembayaran         = fields.Selection(string='Tipe Pembayaran', related="komponen_id.tipe_bayar")
    jangka_waktu_cicilan    = fields.Integer(string='Jangka Waktu Cicilan (bulan)', default="1")

    # @api.onchange('jangka_waktu_cicilan')
    # def _onchange_jangka_waktu_cicilan(self):
    #     if self.jangka_waktu_cicilan:
    #         self.invoice_date_due = date.today() + relativedelta(months=self.jangka_waktu_cicilan)

    # virtual_account_bsi  = fields.Char(string='Virtual Account', copy=False)
    # nomer_pembayaran_bsi = fields.Char(string='No. Pembayaran', copy=False)
    # status_invoice_bsi   = fields.Selection(string='Status BSI', default="belum_terkirim", selection=[('belum_terkirim', 'Tidak Tervalidasi'), ('terkirim', 'Terkirim'), ('dihapus', 'Dihapus'), ('tervalidasi','Tervalidasi')], copy=False)
    virtual_account_bsi  = fields.Char(string='Virtual Account', related="siswa_id.va_pengiriman_tagihan_bsi")
    nomer_pembayaran_bsi = fields.Char(string='No. Pembayaran', related="siswa_id.nomer_pengiriman_tagihan_bsi")
    status_invoice_bsi   = fields.Selection(string='Status BSI', related="siswa_id.status_billing_bsi_tagihan")
    
    payment_channel_bsi                             = fields.Char(string='Channel Pembayaran', copy=False)
    payment_ammount_bsi                             = fields.Float(string='Total Nominal', copy=False)
    payment_fee_bsi                                 = fields.Float(string='Total Fee', copy=False)
    payment_penanggung_fee_bsi                      = fields.Char(string='Penanggung Fee', copy=False)
    payment_total_nominal_pembayaran_dan_fee_bsi    = fields.Float(string='Total Nominal Pembayaran dan Fee', copy=False)
    status_validasi_bsi                             = fields.Char(string='Status Validasi', copy=False)
    watktu_pembayaran_bsi                           = fields.Char('Waktu Dibayar', copy=False)
    keterangan                                      = fields.Text('Ketarangan', copy=False)

    response   = fields.Text('Response', copy=False)
    
    # def send_data_to_bsi(self):
    #     for rec in self:
    #         jurnal_pembayaran_bsi = int(self.env['ir.config_parameter'].sudo().get_param('pesantren_integrasi_bsi.bsi_jurnal_id')) or False
    #         if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False or jurnal_pembayaran_bsi == False:
    #             raise UserError("Harap mengatur jurnal pembayaran bsi, url, client id, secret key BSI terlebih dahulu")

    #         if rec.state == 'posted' and rec.status_invoice_bsi not in ['terkirim', 'tervalidasi']:
    #             # untuk epired date
    #             dt                      = datetime.combine(rec.invoice_date_due, time.max)
    #             datetime_now_iso_fromat = dt.isoformat()

    #             cid              = get_client_id()
    #             customer_name    = rec.partner_id.name or rec.orangtua_id.name or ''
    #             customer_email   = rec.orangtua_id.email or rec.partner_id.email or ''
    #             customer_mobile  = rec.orangtua_id.phone or rec.partner_id.mobile or ''

    #             virtual_account  = self.siswa_id.virtual_account.replace("-", "")
    #             nomor_pembayaran = virtual_account[4:]

    #             appendix = 'c'
    #             if rec.tipe_pembayaran == 'tunai': 
    #                 appendix = 'm'
    #             elif rec.tipe_pembayaran == 'cicil':
    #                 appendix = 'o'

    #             data = {
    #                 "type"             : "createbilling",
    #                 "client_id"        : cid,
    #                 "trx_id"           : rec.name,
    #                 "trx_amount"       : rec.amount_residual,
    #                 "billing_type"     : appendix,
    #                 "customer_name"    : customer_name,
    #                 "customer_email"   : customer_email,
    #                 "customer_phone"   : customer_mobile,
    #                 "virtual_account"  : virtual_account,
    #                 "datetime_expired" : datetime_now_iso_fromat,
    #                 # 'action_pembayaran_lebih' : 'Dimasukkan ke VA Pelanggan & Tutup Tagihan',
    #                 "description"      : "Pembayaran Invoice " + rec.name
    #             }

    #             billing_bsi = create_billing(data)

    #             rec.response    = json.dumps(billing_bsi, indent=2)
    #             if billing_bsi['status'] == 'sukses':
    #                 rec.status_invoice_bsi    = 'terkirim'
    #                 rec.nomer_pembayaran_bsi  = nomor_pembayaran
    #                 rec.virtual_account_bsi   = billing_bsi['response']['virtual_account']

    # def send_single_data_to_bsi(self):
    #     jurnal_pembayaran_bsi = int(self.env['ir.config_parameter'].sudo().get_param('pesantren_integrasi_bsi.bsi_jurnal_id')) or False
    #     if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False or jurnal_pembayaran_bsi == False:
    #         raise UserError("Harap mengatur jurnal pembayaran bsi, url, client id, secret key BSI terlebih dahulu")

    #     if self.state == 'posted' and self.status_invoice_bsi not in ['terkirim', 'tervalidasi']:
    #         # untuk epired date
    #         dt                      = datetime.combine(self.invoice_date_due, time.max)
    #         datetime_now_iso_fromat = dt.isoformat()

    #         cid              = get_client_id()
    #         customer_name    = self.partner_id.name or self.orangtua_id.name or ''
    #         customer_email   = self.orangtua_id.email or self.partner_id.email or ''
    #         customer_mobile  = self.orangtua_id.phone or self.partner_id.mobile or ''
            
    #         virtual_account  = self.siswa_id.virtual_account.replace("-", "")
    #         nomor_pembayaran = virtual_account[4:]

    #         appendix = 'c'
    #         if self.tipe_pembayaran == 'tunai': 
    #             appendix = 'm'
    #         elif self.tipe_pembayaran == 'cicil':
    #             appendix = 'o'

    #         data = {
    #             "type"             : "createbilling",
    #             "client_id"        : cid,
    #             "trx_id"           : self.name,
    #             "trx_amount"       : self.amount_residual,
    #             "billing_type"     : appendix,
    #             "customer_name"    : customer_name,
    #             "customer_email"   : customer_email,
    #             "customer_phone"   : customer_mobile,
    #             "virtual_account"  : virtual_account,
    #             "datetime_expired" : datetime_now_iso_fromat,
    #             # 'action_pembayaran_lebih' : 'Dimasukkan ke VA Pelanggan & Tutup Tagihan',
    #             "description"      : "Pembayaran Invoice " + self.name
    #         }

    #         billing_bsi = create_billing(data)

    #         self.response = json.dumps(billing_bsi, indent=2)
    #         if billing_bsi['status'] == 'sukses':
    #             self.status_invoice_bsi    = 'terkirim'
    #             self.nomer_pembayaran_bsi  = nomor_pembayaran
    #             self.virtual_account_bsi   = billing_bsi['response']['virtual_account']
            
    #             return notif_sukses("Berhasil mengirim billing BSI")
    #         else:
    #             return notif_gagal("Gagal mengirim billing BSI")

    # def update_data_to_bsi(self):
    #     jurnal_pembayaran_bsi = int(self.env['ir.config_parameter'].sudo().get_param('pesantren_integrasi_bsi.bsi_jurnal_id')) or False
    #     if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False or jurnal_pembayaran_bsi == False:
    #         raise UserError("Harap mengatur jurnal pembayaran bsi, url, client id, secret key BSI terlebih dahulu")

    #     dt                      = datetime.combine(self.invoice_date_due, time.max)
    #     datetime_now_iso_fromat = dt.isoformat()

    #     cid              = get_client_id()
    #     customer_name    = self.partner_id.name or self.orangtua_id.name or ''
    #     customer_email   = self.orangtua_id.email or self.partner_id.email or ''
    #     customer_mobile  = self.orangtua_id.phone or self.partner_id.mobile or ''

    #     data = {
    #         "type"             : "updatebilling",
    #         "client_id"        : cid,
    #         "trx_id"           : self.name,
    #         "trx_amount"       : self.amount_residual,
    #         "customer_name"    : customer_name,
    #         "customer_email"   : customer_email,
    #         "customer_phone"   : customer_mobile,
    #         "datetime_expired" : datetime_now_iso_fromat,
    #         "description"      : "Pembayaran Invoice " + self.name
    #     }

    #     billing_bsi = update_billing(data)

    #     self.response = json.dumps(billing_bsi, indent=2)
    #     if billing_bsi['status'] == 'sukses':
    #         return notif_sukses("Berhasil mengupdate billing BSI")
    #     else:
    #         return notif_gagal("Gagal mengupdate billing BSI")


    # def delete_data_to_bsi(self):
    #     jurnal_pembayaran_bsi = int(self.env['ir.config_parameter'].sudo().get_param('pesantren_integrasi_bsi.bsi_jurnal_id')) or False
    #     if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False or jurnal_pembayaran_bsi == False:
    #         raise UserError("Harap mengatur jurnal pembayaran bsi, url, client id, secret key BSI terlebih dahulu")

    #     cid              = get_client_id()
    #     data = {
    #         "type"             : "deletebilling",
    #         "client_id"        : cid,
    #         "trx_id"           : self.name,
    #     }

    #     billing_bsi = delete_billing(data)

    #     self.response = json.dumps(billing_bsi, indent=2)
    #     if billing_bsi['status'] == 'sukses':
    #         self.status_invoice_bsi  = 'dihapus'
    #         return notif_sukses("Berhasil menghapus billing BSI")
    #     else:
    #         return notif_gagal("Gagal menghapus billing BSI")