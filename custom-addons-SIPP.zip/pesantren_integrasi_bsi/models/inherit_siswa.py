from odoo import api, fields, models

from ..tools.integrasi_bsi import *
from datetime import datetime, date, time
from dateutil.relativedelta import relativedelta
import pytz


from odoo.exceptions import UserError


class cdnSiswa(models.Model):
    _inherit = 'cdn.siswa'

    # uang saku
    nama_billing_uang_saku_bsi      = fields.Char(string='Billing Uang Saku BSI', copy=False)
    nomer_pengiriman_uang_saku_bsi  = fields.Char(string='No. Pengiriman Uang Saku', copy=False)
    va_pengiriman_uang_saku_bsi     = fields.Char(string='VA Uang Saku', copy=False)
    riwayat_uang_saku_bsi           = fields.One2many(comodel_name='cdn.riwayat.uang.saku.bsi', inverse_name='siswa_id', string='Riwayat Pengiriman Uang Saku BSI')
    
    response                        = fields.Text('Response Uang Saku BSI')
    status_billing_bsi_uang_saku    = fields.Selection(string='Status BSI Uang Saku', default="belum_terhubung", selection=[('belum_terhubung', 'Belum Terhubung'), ('terhubung', 'Terhubung'), ('dihapus', 'Dihapus')], copy=False)
    
    # tagihan
    nama_billing_tagihan_bsi      = fields.Char(string='Billing Tagihan BSI', copy=False)
    nomer_pengiriman_tagihan_bsi  = fields.Char(string='No. Pembayaran Tagihan', copy=False)
    va_pengiriman_tagihan_bsi     = fields.Char(string='VA Pembayaran Tagihan', copy=False)
    riwayat_tagihan_bsi           = fields.One2many(comodel_name='cdn.riwayat.tagihan.bsi', inverse_name='siswa_id', string='Riwayat Pembayaran Tagihan BSI')
    
    response_tagihan              = fields.Text('Response Tagihan BSI')
    status_billing_bsi_tagihan    = fields.Selection(string='Status BSI Tagihan', default="belum_terhubung", selection=[('belum_terhubung', 'Belum Terhubung'), ('terhubung', 'Terhubung'), ('dihapus', 'Dihapus')], copy=False)

    status_billing_bsi_all        = fields.Selection(string='Status BSI', selection=[('tidak_terhubung', 'Tidak Terhubung'), ('terhubung_sebagian', 'Terhubung Sebagian'), ('terhubung', 'Terhubung')], compute='_compute_status_billing_bsi_all', copy=False)

    @api.depends('status_billing_bsi_uang_saku','status_billing_bsi_tagihan')
    def _compute_status_billing_bsi_all(self):
        for rec in self:
            if rec.status_billing_bsi_uang_saku == 'terhubung' and rec.status_billing_bsi_tagihan == 'terhubung':
                rec.status_billing_bsi_all = 'terhubung'

            elif rec.status_billing_bsi_uang_saku == 'terhubung' and rec.status_billing_bsi_tagihan != 'terhubung':
                rec.status_billing_bsi_all = 'terhubung_sebagian'

            elif rec.status_billing_bsi_uang_saku != 'terhubung' and rec.status_billing_bsi_tagihan == 'terhubung':
                rec.status_billing_bsi_all = 'terhubung_sebagian'
            
            else:
                rec.status_billing_bsi_all = 'tidak_terhubung'

    def send_data_billing_siswa_to_bsi(self):
        for rec in self:
            if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False:
                raise UserError("Harap mengatur url, client id, secret key BSI terlebih dahulu")

            # untuk expired datetime (10 tahun)
            date_due                = date.today() + relativedelta(years=10)
            dt                      = datetime.combine(date_due, time.max)
            datetime_now_iso_fromat = dt.isoformat()

            cid              = get_client_id()
            customer_name    = rec.partner_id.name or rec.orangtua_id.name or ''
            customer_email   = rec.orangtua_id.email or rec.partner_id.email or ''
            customer_mobile  = rec.orangtua_id.phone or rec.partner_id.mobile or ''

            appendix = 'n'
            if self.status_billing_bsi_uang_saku != 'terhubung':
                va_saku          = self.siswa_id.va_saku.replace("-", "")
                nomor_pengiriman_saku = va_saku[4:]
                data = {
                    "type"             : "createbilling",
                    "client_id"        : cid,
                    "trx_id"           : "SAKU"+rec.nis,
                    "trx_amount"       : 0,
                    "billing_type"     : appendix,
                    "customer_name"    : customer_name,
                    "customer_email"   : customer_email,
                    "customer_phone"   : customer_mobile,
                    "virtual_account"  : va_saku,
                    "datetime_expired" : datetime_now_iso_fromat,
                    "description"      : 'Uang Saku',
                    "info"             : 'Uang Saku',
                }

                billing_saku_bsi    = create_billing(data)
                rec.response    = json.dumps(billing_saku_bsi, indent=2)
                if billing_saku_bsi['status'] == 'sukses':
                    rec.nomer_pengiriman_uang_saku_bsi  = nomor_pengiriman_saku
                    rec.va_pengiriman_uang_saku_bsi     = billing_saku_bsi['response']['virtual_account']
                    rec.nama_billing_uang_saku_bsi      = billing_saku_bsi['response']['trx_id']
                    rec.status_billing_bsi_uang_saku    = 'terhubung'
            
            if self.status_billing_bsi_tagihan != 'terhubung':
                va_tagihan       = self.siswa_id.virtual_account.replace("-", "")
                nomor_pengiriman_tagihan = va_tagihan[4:]
                data_tagihan = {
                    "type"             : "createbilling",
                    "client_id"        : cid,
                    "trx_id"           : "Tagihan"+rec.nis,
                    "trx_amount"       : 0,
                    "billing_type"     : appendix,
                    "customer_name"    : customer_name,
                    "customer_email"   : customer_email,
                    "customer_phone"   : customer_mobile,
                    "virtual_account"  : va_tagihan,
                    "datetime_expired" : datetime_now_iso_fromat,
                    "description"      : 'Pembayaran Tagihan',
                    "info"             : 'Pembayaran Tagihan',
                }

                billing_tagihan_bsi  = create_billing(data_tagihan)
                rec.response_tagihan = json.dumps(billing_tagihan_bsi, indent=2)
                if billing_tagihan_bsi['status'] == 'sukses':
                    rec.nomer_pengiriman_tagihan_bsi  = nomor_pengiriman_tagihan
                    rec.va_pengiriman_tagihan_bsi     = billing_tagihan_bsi['response']['virtual_account']
                    rec.nama_billing_tagihan_bsi      = billing_tagihan_bsi['response']['trx_id']
                    rec.status_billing_bsi_tagihan    = 'terhubung'

    def send_single_data_billing_siswa_to_bsi(self):
        if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False:
            raise UserError("Harap mengatur url, client id, secret key BSI terlebih dahulu")

        # untuk expired datetime (10 tahun)
        date_due                = date.today() + relativedelta(years=10)
        dt                      = datetime.combine(date_due, time.max)
        datetime_now_iso_fromat = dt.isoformat()

        cid              = get_client_id()
        customer_name    = self.partner_id.name or self.orangtua_id.name or ''
        customer_email   = self.orangtua_id.email or self.partner_id.email or ''
        customer_mobile  = self.orangtua_id.phone or self.partner_id.mobile or ''

        appendix = 'n'
        if self.status_billing_bsi_uang_saku != 'terhubung':
            if self.siswa_id.va_saku:
                va_saku               = self.siswa_id.va_saku.replace("-", "")
                nomor_pengiriman_saku = va_saku[4:]

                data = {
                    "type"             : "createbilling",
                    "client_id"        : cid,
                    "trx_id"           : "SAKU"+self.nis,
                    "trx_amount"       : 0,
                    "billing_type"     : appendix,
                    "customer_name"    : customer_name,
                    "customer_email"   : customer_email,
                    "customer_phone"   : customer_mobile,
                    "virtual_account"  : va_saku,
                    "datetime_expired" : datetime_now_iso_fromat,
                    "description"      : 'Uang Saku',
                    "info"             : 'Uang Saku',
                }

                billing_saku_bsi    = create_billing(data)
                self.response    = json.dumps(billing_saku_bsi, indent=2)
                if billing_saku_bsi['status'] == 'sukses':
                    self.nomer_pengiriman_uang_saku_bsi  = nomor_pengiriman_saku
                    self.va_pengiriman_uang_saku_bsi     = billing_saku_bsi['response']['virtual_account']
                    self.nama_billing_uang_saku_bsi      = billing_saku_bsi['response']['trx_id']
                    self.status_billing_bsi_uang_saku    = 'terhubung'
            else:
                self.va_pengiriman_uang_saku_bsi     = 'va uang saku kosong'
                billing_saku_bsi = {
                    'status' : 'gagal'
                }
        else:
            billing_saku_bsi = {
                'status' : 'sukses'
            }
        
        if self.status_billing_bsi_tagihan != 'terhubung':
            if self.siswa_id.virtual_account:
                va_tagihan       = self.siswa_id.virtual_account.replace("-", "")
                nomor_pengiriman_tagihan = va_tagihan[4:]
                data_tagihan = {
                    "type"             : "createbilling",
                    "client_id"        : cid,
                    "trx_id"           : "Tagihan"+self.nis,
                    "trx_amount"       : 0,
                    "billing_type"     : appendix,
                    "customer_name"    : customer_name,
                    "customer_email"   : customer_email,
                    "customer_phone"   : customer_mobile,
                    "virtual_account"  : va_tagihan,
                    "datetime_expired" : datetime_now_iso_fromat,
                    "description"      : 'Pembayaran Tagihan',
                    "info"             : 'Pembayaran Tagihan',
                }

                billing_tagihan_bsi  = create_billing(data_tagihan)
                self.response_tagihan = json.dumps(billing_tagihan_bsi, indent=2)
                if billing_tagihan_bsi['status'] == 'sukses':
                    self.nomer_pengiriman_tagihan_bsi  = nomor_pengiriman_tagihan
                    self.va_pengiriman_tagihan_bsi     = billing_tagihan_bsi['response']['virtual_account']
                    self.nama_billing_tagihan_bsi      = billing_tagihan_bsi['response']['trx_id']
                    self.status_billing_bsi_tagihan      = 'terhubung'
            else:
                self.va_pengiriman_tagihan_bsi     = 'va tagihan kosong'
                billing_tagihan_bsi = {
                    'status' : 'gagal'
                }
        
        else:
            billing_tagihan_bsi = {
                'status' : 'sukses'
            }

        if billing_saku_bsi['status'] == 'sukses' and billing_tagihan_bsi['status'] == 'sukses':
            return notif_sukses("Berhasil membuat billing BSI")

        elif billing_saku_bsi['status'] == 'sukses' and billing_tagihan_bsi['status'] != 'sukses':
            return notif_warning("Berhasil membuat billing BSI uang saku, gagal membuat billing BSI tagihan")

        elif billing_saku_bsi['status'] != 'sukses' and billing_tagihan_bsi['status'] == 'sukses':
            return notif_warning("Berhasil membuat billing BSI tagihan, gagal membuat billing BSI uang saku")
        
        else:
            return notif_gagal("Gagal membuat billing BSI")

        # self.response    = json.dumps(billing_bsi, indent=2)
        # if billing_bsi['status'] == 'sukses':
        #     self.status_billing_bsi_uang_saku    = 'terhubung'
        #     self.nomer_pengiriman_uang_saku_bsi  = nomor_pengiriman
        #     self.va_pengiriman_uang_saku_bsi     = billing_bsi['response']['virtual_account']
        #     self.nama_billing_uang_saku_bsi      = billing_bsi['response']['trx_id']

        #     return notif_sukses("Berhasil membuat billing BSI uang saku")
        # else:
        #     return notif_gagal("Gagal membuat billing BSI uang saku")
    
    def delete_single_data_billing_uang_saku_siswa_from_bsi(self):
        if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False:
            raise UserError("Harap mengatur url, client id, secret key BSI terlebih dahulu")

        cid              = get_client_id()
        data = {
            "type"             : "deletebilling",
            "client_id"        : cid,
            "trx_id"           : self.nama_billing_uang_saku_bsi,
        }

        billing_bsi = delete_billing(data)

        self.response = json.dumps(billing_bsi, indent=2)
        if billing_bsi['status'] == 'sukses':
            self.status_billing_bsi_uang_saku   = 'dihapus'
            self.nama_billing_uang_saku_bsi     = False
            self.va_pengiriman_uang_saku_bsi    = False
            self.nomer_pengiriman_uang_saku_bsi = False
            
            return notif_sukses("Berhasil menghapus billing uang saku BSI")
        else:
            return notif_gagal("Gagal menghapus billing uang saku BSI")
    
    def delete_single_data_billing_tagihan_siswa_from_bsi(self):
        if get_client_id() == False or get_secret_key_notifikasi_http() == False or get_bsi_url() == False:
            raise UserError("Harap mengatur url, client id, secret key BSI terlebih dahulu")

        cid              = get_client_id()
        data = {
            "type"             : "deletebilling",
            "client_id"        : cid,
            "trx_id"           : self.nama_billing_tagihan_bsi,
        }

        billing_bsi = delete_billing(data)

        self.response_tagihan = json.dumps(billing_bsi, indent=2)
        if billing_bsi['status'] == 'sukses':
            self.status_billing_bsi_tagihan   = 'dihapus'
            self.nama_billing_tagihan_bsi     = False
            self.va_pengiriman_tagihan_bsi    = False
            self.nomer_pengiriman_tagihan_bsi = False

            return notif_sukses("Berhasil menghapus billing tagihan BSI")
        else:
            return notif_gagal("Gagal menghapus billing tagihan BSI")

class CdnRiwayatUangSakuBsi(models.Model):
    _name = 'cdn.riwayat.uang.saku.bsi'
    _description = 'Riwayat Pengiriman Uang Saku via Bsi'

    siswa_id              = fields.Many2one(comodel_name='cdn.siswa', string='Siswa')
    payment_channel_bsi   = fields.Char(string='Channel', copy=False)
    payment_ammount_bsi   = fields.Float(string='Total Nominal', copy=False)
    watktu_dikirim_bsi    = fields.Char('Waktu Dikirim', copy=False)

class CdnRiwayatTagihanBsi(models.Model):
    _name = 'cdn.riwayat.tagihan.bsi'
    _description = 'Riwayat Pembayaran Tagihan via Bsi'

    siswa_id              = fields.Many2one(comodel_name='cdn.siswa', string='Siswa')
    payment_channel_bsi   = fields.Char(string='Channel', copy=False)
    payment_ammount_bsi   = fields.Float(string='Total Nominal', copy=False)
    watktu_dikirim_bsi    = fields.Char('Waktu Dikirim', copy=False)
    keterangan            = fields.Text('Keterangan', copy=False)
    is_valid              = fields.Boolean(string='Pembayaran valid dengan tagihan?')

    def tandai_valid(self):
        # Ambil waktu UTC sekarang
        utc_now = datetime.utcnow()

        # Ambil timezone user, fallback ke UTC jika tidak tersedia
        user_tz = self.env.user.tz or 'UTC'

        # Konversi timezone
        local_tz = pytz.timezone(user_tz)
        waktu_wib = pytz.utc.localize(utc_now).astimezone(local_tz)

        # Format sesuai keinginan
        waktu_sekarang = waktu_wib.strftime("%Y-%m-%d %H:%M:%S")

        self.is_valid   = True
        self.keterangan = f"Pembayaran tidak diketahui, pembayaran divalidasi pada {waktu_sekarang}"
    