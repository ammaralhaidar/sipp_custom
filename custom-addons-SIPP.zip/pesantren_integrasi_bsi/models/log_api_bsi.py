from odoo import api, fields, models
from odoo.http import request
from odoo.exceptions import UserError
import subprocess
from odoo.tools import config

from ..tools.integrasi_bsi import *
import requests

class logBsi(models.Model):
    _name = 'cdn.log.api.bsi'
    _description = 'Log Api Pengiriman BSI'
    _rec_name    = 'datetime'
    _order       = 'id desc'

    datetime      = fields.Datetime(string='Datetime', default=fields.Datetime.now)
    name          = fields.Char(string='Nama', default="-")
    method        = fields.Char(string='Method', default="-")
    url           = fields.Char(string='URL', default="-")
    headers       = fields.Text(string='Headers', default="-")
    data          = fields.Text(string='Data', default="-")
    payload       = fields.Text(string='Payload', default="-")
    status        = fields.Char(string='Status', default="-")
    response      = fields.Text(string='Response', default="-")
    id_tagihan    = fields.Text(string='ID Tagihan', default="-")
    
    def get_hostname(self):
        try:
            result = subprocess.check_output(['hostname', '-i']).decode().strip()
            return f"http://{result}:{config.get('http_port', '8069')}"
        except Exception as e:
            return f"Error: {e}"

    def send_again(self):
        try:
            # base_url = request.env['ir.config_parameter'].sudo().get_param('bsi_base_url_pn')
            # if not base_url:
            #     raise UserError('URL bsi_base_url_pn pada config parameter belum diisi, silahkan isi url anda saat ini')

            base_url = self.get_hostname()
            headers = {
                'Content-Type': 'application/json'
            }
            payload = self.payload

            response = requests.request("POST", base_url+'/bsi/payment-notification', headers=headers, data=payload)

            if(response.status_code == 200):
                self.response = json.dumps(response.json(), indent=2)
                self.name = 'Payment Notification BSI'
                return notif_sukses("sukses kirim ulang")
            else:
                self.response = response.status_code
                return notif_gagal("Gagal kirim ulang")
        
        except Exception as err:
            self.response = traceback.format_exc()
            return notif_gagal("Gagal kirim ulang")