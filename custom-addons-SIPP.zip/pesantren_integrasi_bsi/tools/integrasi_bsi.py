from odoo.http import request

import requests
import json
import time
import base64
import traceback

def save_log(url, method, name, headers, data, payload, status, response, id_tagihan='-'):
   data = {
      'url'           : url,
      'name'          : name,
      'method'        : method,
      'headers'       : headers,
      'payload'       : payload,
      'data'          : data,
      'status'        : status,
      'response'      : response,
      'id_tagihan'    : id_tagihan,
   }

   request.env['cdn.log.api.bsi'].sudo().create(data)

def notif_sukses(msg: str):
    return  {
        'type': 'ir.actions.client',
        'tag': 'display_notification',
        'params': {
            'title': 'Berhasil',
            'type': 'success',
            'message': msg,
            'sticky': False,
            'next' : {
                'type': 'ir.actions.act_window_close'
            }
        }
    }

def notif_warning(msg: str):
    return  {
        'type': 'ir.actions.client',
        'tag': 'display_notification',
        'params': {
            'title': 'Berhasil',
            'type': 'warning',
            'message': msg,
            'sticky': False,
            'next' : {
                'type': 'ir.actions.act_window_close'
            }
        }
    }

def notif_gagal(msg: str):
    return  {
        'type': 'ir.actions.client',
        'tag': 'display_notification',
        'params': {
            'title': 'Gagal',
            'type': 'danger',
            'message': msg,
            'sticky': False,
            'next' : {
                'type': 'ir.actions.act_window_close'
            }
        }
    }


def get_bsi_url():
    return request.env['ir.config_parameter'].sudo().get_param('bsi_url')

def get_client_id():
    return request.env['ir.config_parameter'].sudo().get_param('bsi_client_id')

def get_secret_key_notifikasi_http():
    return request.env['ir.config_parameter'].sudo().get_param('bsi_secret_key_notifikasi_http')

def get_secret_key_host_to_host():
    return request.env['ir.config_parameter'].sudo().get_param('bsi_secret_key_host_to_host')

def enc(string: str, key: str) -> str:
    result = ''
    strls = len(string)
    strlk = len(key)

    for i in range(strls):
        char = string[i]
        key_index = (i % strlk) - 1
        keychar = key[key_index]
        char_code = (ord(char) + ord(keychar)) % 128
        result += chr(char_code)

    return result

def encrypt(json_data: dict, cid: str, secret: str) -> str:
    reversed_time = str(int(time.time()))[::-1]
    payload = f"{reversed_time}.{json.dumps(json_data)}"
    return double_encrypt(payload, cid, secret)

def double_encrypt(string: str, cid: str, secret: str) -> str:
    result = enc(string, cid)
    result = enc(result, secret)
    b64_encoded = base64.urlsafe_b64encode(result.encode('latin1')).decode('utf-8')
    return b64_encoded.rstrip('=')

def dec(string: str, key: str) -> str:
    result = ''
    strls = len(string)
    strlk = len(key)

    for i in range(strls):
        char = string[i]
        key_index = (i % strlk) - 1
        keychar = key[key_index]
        char_code = ((ord(char) - ord(keychar)) + 256) % 128
        result += chr(char_code)

    return result

def double_decrypt(string: str, cid: str, secret: str) -> str:
    padding = '=' * ((4 - len(string) % 4) % 4)
    string_padded = string + padding
    b64_decoded = base64.urlsafe_b64decode(string_padded.encode('utf-8')).decode('latin1')
    result = dec(b64_decoded, cid)
    result = dec(result, secret)
    return result

def decrypt(hashed_string: str, cid: str, secret: str):
    parsed_string = double_decrypt(hashed_string, cid, secret)
    parts = parsed_string.split('.', 1)
    if len(parts) != 2:
        return None
    timestamp, data = parts
    if ts_diff(timestamp):
        return json.loads(data)
    return None

def ts_diff(reversed_ts: str, threshold_seconds: int = 300) -> bool:
    """
    Cek apakah timestamp masih valid berdasarkan batas waktu tertentu (default: 5 menit)
    """
    try:
        original_ts = int(reversed_ts[::-1])
        now_ts = int(time.time())
        return abs(now_ts - original_ts) <= threshold_seconds
    except ValueError:
        return False


# post create billing
def create_billing(data):
    endpoint      = '/ext/bnis/?fungsi=vabilling'
    url           = get_bsi_url() + endpoint
    client_id     = get_client_id()
    secret_key    = get_secret_key_notifikasi_http()

    data_encrypt = encrypt(data, client_id, secret_key)

    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        "client_id" : client_id,
        "data"      : data_encrypt
    }

    try:
        response = requests.request("POST", url, headers=headers, data=json.dumps(payload))

        if(response.status_code < 200 or response.status_code >= 300):
            save_log(
                url, 
                "POST", 
                "Create Billing BSI", 
                json.dumps(headers, indent=2), 
                json.dumps(data, indent=2), 
                json.dumps(payload, indent=2), 
                response.status_code, 
                json.dumps(response.json(), indent=2)
            )

            return {'status': 'gagal', 'response' : json.dumps(response.json(), indent=2), 'status_code': response.status_code}
        else:
            response.raise_for_status()  # Memastikan permintaan berhasil
            response_output = response.json()

            save_log(
                url, 
                "POST", 
                "Create Billing BSI", 
                json.dumps(headers, indent=2), 
                json.dumps(data, indent=2), 
                json.dumps(payload, indent=2), 
                response.status_code, 
                json.dumps(response_output, indent=2)
            )
            if response_output['status'] == '000':
                response_data = decrypt(
                    response_output['data'],
                    client_id,
                    secret_key
                )
                return {'status': 'sukses', 'response' : response_data, 'status_code': response.status_code}
            else:
                return {'status': 'gagal', 'response' : json.dumps(response_output, indent=2), 'status_code': response.status_code}
            
    except Exception as err:
        err_traceback = traceback.format_exc()
        save_log(
            url, 
            "POST", 
            "Create Billing BSI - Error Code", 
            json.dumps(headers, indent=2), 
            json.dumps(data, indent=2), 
            json.dumps(payload, indent=2),
            '-',
            err_traceback,
        )

        return {'status': 'gagal', 'response' : f'Error : {err}', 'status_code': '-'}

    
# update billing
def update_billing(data):
    endpoint      = '/ext/bnis/?fungsi=vabilling'
    url           = get_bsi_url() + endpoint
    client_id     = get_client_id()
    secret_key    = get_secret_key_notifikasi_http()

    data_encrypt = encrypt(data, client_id, secret_key)

    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        "client_id" : client_id,
        "data"      : data_encrypt
    }

    try:
        response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
        
        if(response.status_code < 200 or response.status_code >= 300):
            save_log(
                url, 
                "POST", 
                "Update Billing BSI", 
                json.dumps(headers, indent=2), 
                json.dumps(data, indent=2), 
                json.dumps(payload, indent=2), 
                response.status_code, 
                json.dumps(response.json(), indent=2)
            )

            return {'status': 'gagal', 'response' : json.dumps(response.json(), indent=2), 'status_code': response.status_code}
        else:
            response.raise_for_status()  # Memastikan permintaan berhasil
            response_output = response.json()
        
            save_log(
                url, 
                "POST", 
                "Update Billing BSI", 
                json.dumps(headers, indent=2), 
                json.dumps(data, indent=2), 
                json.dumps(payload, indent=2), 
                response.status_code, 
                json.dumps(response_output, indent=2)
            )
            if response_output['status'] == '000':
                response_data = decrypt(
                    response_output['data'],
                    client_id,
                    secret_key
                )
                return {'status': 'sukses', 'response' : response_data, 'status_code': response.status_code}
            else:
                return {'status': 'gagal', 'response' : json.dumps(response_output, indent=2), 'status_code': response.status_code}
            
    except Exception as err:
        err_traceback = traceback.format_exc()
        save_log(
            url, 
            "POST", 
            "Update Billing BSI - Error Code", 
            json.dumps(headers, indent=2), 
            json.dumps(data, indent=2), 
            json.dumps(payload, indent=2),
            '-',
            err_traceback,
        )

        return {'status': 'gagal', 'response' : f'Error : {err}', 'status_code': '-'}

# delete billing
def delete_billing(data):
    endpoint      = '/ext/bnis/?fungsi=vabilling'
    url           = get_bsi_url() + endpoint
    client_id     = get_client_id()
    secret_key    = get_secret_key_notifikasi_http()

    data_encrypt = encrypt(data, client_id, secret_key)

    headers = {
        'Content-Type': 'application/json'
    }
    payload = {
        "client_id" : client_id,
        "data"      : data_encrypt
    }

    try:
        response = requests.request("POST", url, headers=headers, data=json.dumps(payload))
        
        if(response.status_code < 200 or response.status_code >= 300):
            save_log(
                url, 
                "POST", 
                "Delete Billing BSI", 
                json.dumps(headers, indent=2), 
                json.dumps(data, indent=2), 
                json.dumps(payload, indent=2), 
                response.status_code, 
                json.dumps(response.json(), indent=2)
            )

            return {'status': 'gagal', 'response' : json.dumps(response.json(), indent=2), 'status_code': response.status_code}
        else:
            response.raise_for_status()  # Memastikan permintaan berhasil
            response_output = response.json()
        
            save_log(
                url, 
                "POST", 
                "Delete Billing BSI", 
                json.dumps(headers, indent=2), 
                json.dumps(data, indent=2), 
                json.dumps(payload, indent=2), 
                response.status_code, 
                json.dumps(response_output, indent=2)
            )
            if response_output['status'] == '000':
                response_data = decrypt(
                    response_output['data'],
                    client_id,
                    secret_key
                )
                return {'status': 'sukses', 'response' : response_data, 'status_code': response.status_code}
            else:
                return {'status': 'gagal', 'response' : json.dumps(response_output, indent=2), 'status_code': response.status_code}
            
    except Exception as err:
        err_traceback = traceback.format_exc()
        save_log(
            url, 
            "POST", 
            "Delete Billing BSI - Error Code", 
            json.dumps(headers, indent=2), 
            json.dumps(data, indent=2), 
            json.dumps(payload, indent=2),
            '-',
            err_traceback,
        )

        return {'status': 'gagal', 'response' : f'Error : {err}', 'status_code': '-'}