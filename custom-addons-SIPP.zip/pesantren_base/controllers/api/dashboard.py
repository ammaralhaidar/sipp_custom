# -*- coding: utf-8 -*-
import json
import pytz
import math
import base64
from odoo import http, fields
from odoo.http import request, Response
from datetime import timedelta

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiDashboard(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    data dashboard untuk aplikasi mobile orang tua.
    """

    @http.route(API_URL + '/dashboard/overview', auth='user', type='http', methods=['GET'], website=False)
    def get_dashboard_overview(self, **kwargs):
        """
        Endpoint ini menggabungkan ringkasan dari endpoint lain
        untuk membangun response dashboard yang lengkap. (Versi Perbaikan)
        """
        try:
            # Panggil fungsi internal untuk mendapatkan data keuangan
            # Kita gunakan .data karena fungsi get_dashboard_keuangan mengembalikan objek Response
            response_keuangan = self.get_dashboard_keuangan()
            data_keuangan = json.loads(response_keuangan.data).get('data', {})

            # Panggil fungsi internal untuk mendapatkan data kesantrian
            response_kesantrian = self.get_dashboard_kesantrian()
            data_kesantrian = json.loads(response_kesantrian.data).get('data', {})
            
            # TODO: Panggil fungsi untuk data akademik di sini jika sudah dibuat
            data_akademik = {}

            # Dapatkan info siswa dasar dari data kesantrian
            siswa_info = {
                'id': data_kesantrian.get('siswa_id'),
                'name': data_kesantrian.get('siswa_name'),
            }

            response_data = {
                'siswa_info': siswa_info,
                'overview_keuangan': data_keuangan,
                'overview_kesantrian': data_kesantrian,
                'overview_akademik': data_akademik,
            }

            return Response(json.dumps({'success': True, 'data': response_data}, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
    
    @http.route(API_URL + '/dashboard/keuangan', auth='user', type='http', methods=['GET'], website=False)
    def get_dashboard_keuangan(self, **kwargs):
        """
        Endpoint ini HANYA mengembalikan ringkasan data keuangan.
        """
        try:
            Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', request.env.user.partner_id.id)])
            if not Orangtua:
                return Response(json.dumps({'success': False, 'error': 'Profil Orang Tua tidak ditemukan'}),
                                content_type='application/json', status=404)

            list_siswa = request.env['cdn.siswa'].search([('orangtua_id', '=', Orangtua.id)])
            if not list_siswa:
                return Response(json.dumps({'success': True, 'data': {}}),
                                content_type='application/json', status=200)

            invoices_aktif = request.env['account.move'].search([
                ('siswa_id', 'in', list_siswa.ids),
                ('state', '=', 'posted'),
                ('payment_state', 'in', ['not_paid', 'partial'])
            ])
            
            total_uang_saku = sum(list_siswa.mapped('partner_id.saldo_uang_saku'))
            total_dompet_kantin = sum(list_siswa.mapped('partner_id.wallet_balance'))

            keuangan_ringkas = {
                'total_tagihan_aktif': sum(invoices_aktif.mapped('amount_residual_signed')),
                'saldo_uang_saku': total_uang_saku,
                'saldo_dompet_kantin': total_dompet_kantin
            }

            return Response(json.dumps({'success': True, 'data': keuangan_ringkas}, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
    

    @http.route(API_URL + '/dashboard/kesantrian', auth='user', type='http', methods=['GET'], website=False)
    def get_dashboard_kesantrian(self, **kwargs):
        """
        Endpoint ini HANYA mengembalikan ringkasan data kesantrian.
        """
        try:
            Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', request.env.user.partner_id.id)])
            if not Orangtua:
                return Response(json.dumps({'success': False, 'error': 'Profil Orang Tua tidak ditemukan'}),
                                content_type='application/json', status=404)

            list_siswa = request.env['cdn.siswa'].search([('orangtua_id', '=', Orangtua.id)])
            if not list_siswa:
                return Response(json.dumps({'success': True, 'data': {}}),
                                content_type='application/json', status=200)
            
            # Untuk ringkasan, kita fokus pada anak pertama saja sebagai default
            siswa = list_siswa[0]

            # --- Logika Kalkulasi Progres Tahfidz ---
            tujuh_hari_lalu = fields.Date.today() - timedelta(days=7)
            domain_tahfidz = [('siswa_id', '=', siswa.id), ('tanggal', '>=', tujuh_hari_lalu)]
            setoran_minggu_ini = request.env['cdn.tahfidz_quran'].search(domain_tahfidz, order='tanggal asc')

            total_baris = 0
            total_halaman = 0
            setoran_terakhir_info = "Belum ada setoran"

            if setoran_minggu_ini:
                total_baris = sum(setoran_minggu_ini.mapped('jml_baris'))
                setoran_pertama = setoran_minggu_ini[0]
                setoran_terakhir = setoran_minggu_ini[-1]
                # Pastikan page_akhir dan page_awal tidak kosong
                if setoran_terakhir.page_akhir and setoran_pertama.page_awal:
                    total_halaman = setoran_terakhir.page_akhir - setoran_pertama.page_awal
                setoran_terakhir_info = f"{setoran_terakhir.surah_id.name} Ayat {setoran_terakhir.ayat_akhir.name}"

            kesantrian_ringkas = {
                'siswa_id': siswa.id, # Kirim ID siswa agar app tahu ini data siapa
                'siswa_name': siswa.name,
                'info_utama': 'Progres Tahfidz (7 Hari Terakhir)',
                'total_baris_disetor': total_baris,
                'total_halaman_progres': total_halaman,
                'setoran_terakhir': setoran_terakhir_info,
            }

            return Response(json.dumps({'success': True, 'data': kesantrian_ringkas}, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
