# -*- coding: utf-8 -*-
import json
from odoo import http
from odoo.http import request

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiAuth(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    otentikasi pengguna (Orang Tua) dari aplikasi mobile.
    """

    @http.route(API_URL + '/session/authenticate', auth='none', type='json', methods=['POST'], csrf=False)
    def authenticate(self, **kw):
        """
        Endpoint untuk login. Menerima db, login, dan password.
        Mengembalikan detail sesi dan profil orang tua jika berhasil.
        """
        # Mengambil data JSON yang dikirim oleh aplikasi mobile
        data = json.loads(request.httprequest.data)
        params = data.get('params', {})
        db = params.get('db')
        login = params.get('login')
        password = params.get('password')

        # Validasi sederhana untuk memastikan semua parameter ada
        if not all([db, login, password]):
            return {'error': {'code': 400, 'message': 'Parameter db, login, dan password wajib diisi'}}

        try:
            # Memvalidasi kredensial menggunakan fungsi bawaan Odoo
            request.session.authenticate(db, login, password)
            
            # Mengambil informasi sesi yang berhasil dibuat
            session_info = request.env['ir.http'].session_info()
            
            # Mencari data 'cdn.orangtua' yang terhubung dengan partner dari user yang login
            orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', session_info.get('partner_id'))])
            
            # Menyiapkan data balasan (response)
            result = {
                'uid': session_info.get('uid'),
                'partner_id': session_info.get('partner_id'),
                'name': session_info.get('name'),
                'username': session_info.get('username'),
                'orangtua_id': False,
                'siswa_id': False, # Mengambil siswa pertama sebagai default
                'avatar_128': False
            }
            
            # Jika profil orang tua ditemukan, tambahkan infonya ke response
            if orangtua:
                result.update({
                    'orangtua_id': orangtua.id,
                    'avatar_128': orangtua.partner_id.avatar_128
                })
                # Jika orang tua punya anak, ambil ID anak pertama untuk kemudahan aplikasi
                if orangtua.siswa_ids:
                    result.update({'siswa_id': orangtua.siswa_ids[0].id})
            
            return result
        
        except Exception as e:
            # Jika terjadi error saat login (misal: password salah)
            return {'error': {'code': 401, 'message': 'Otentikasi Gagal: ' + str(e)}}

    @http.route(API_URL + '/session/logout', auth='user', type='json', methods=['POST'], website=False)
    def logout(self):
        """
        Endpoint untuk logout dari sesi yang sedang aktif.
        """
        # Memanggil fungsi logout bawaan Odoo
        request.session.logout()
        return {'code': 200, 'message': 'Logout Berhasil'}

    @http.route(API_URL + '/ganti_password', auth='user', type='json', methods=['POST'], website=False)
    def api_change_password(self, **kw):
        """
        Endpoint untuk ganti password.
        Ini adalah versi perbaikan yang lebih aman.
        """
        params = request.jsonrequest.get('params', {})
        old_password = params.get('old_password')
        new_password = params.get('new_password')

        if not all([old_password, new_password]):
            return {'error': {'code': 400, 'message': 'Password lama dan baru wajib diisi'}}

        try:
            # Menggunakan fungsi ganti password bawaan Odoo yang aman
            # Fungsi ini otomatis bekerja untuk user yang sedang login (yang token/sesinya digunakan)
            if request.env.user.change_password(old_password, new_password):
                return {'code': 200, 'message': 'Password berhasil diubah'}
            else:
                # Odoo mengembalikan False jika password lama tidak cocok
                return {'error': {'code': 401, 'message': 'Password lama salah'}}
        except Exception as e:
            return {'error': {'code': 500, 'message': 'Terjadi kesalahan: ' + str(e)}}