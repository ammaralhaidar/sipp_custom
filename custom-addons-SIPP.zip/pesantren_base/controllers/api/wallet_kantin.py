# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiWallet(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Wallet dan Transaksi Kantin
    """

    @http.route(API_URL + '/siswa/<int:siswa_id>/transaksi_kantin', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_transaksi_kantin(self, siswa_id, page=1, limit=10, **kwargs):
        """
        Endpoint untuk mengambil riwayat transaksi/belanja siswa di kantin (POS)
        dengan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 10

            # Domain: Cari transaksi POS berdasarkan partner_id siswa
            domain = [('partner_id', '=', Siswa.partner_id.id)]
            
            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['pos.order'].search_count(domain)
            offset = (page - 1) * limit

            pos_orders = request.env['pos.order'].search(
                domain,
                limit=limit,
                offset=offset,
                order='date_order desc'
            )

            # --- Langkah 4: Siapkan Response JSON yang Rapi ---
            hasil_akhir = []
            for order in pos_orders:
                rincian_belanja = []
                for line in order.lines:
                    rincian_belanja.append({
                        'produk': line.full_product_name,
                        'jumlah': line.qty,
                        'harga_satuan': line.price_unit,
                        'subtotal': line.price_subtotal_incl,
                    })
                
                hasil_akhir.append({
                    'id': order.id,
                    'nomor_transaksi': order.name,
                    'tanggal': order.date_order.strftime('%Y-%m-%d %H:%M:%S'),
                    'total_belanja': order.amount_total,
                    'rincian': rincian_belanja
                })

            response_data = {
                'success': True,
                'data': hasil_akhir,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
