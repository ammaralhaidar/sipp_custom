# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'


class ApiPerizinan(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Perizinan.
    """

    @http.route(API_URL + '/siswa/<int:siswa_id>/perizinan', auth='user', type='http', methods=['POST'], website=False, csrf=False)
    def ajukan_izin(self, siswa_id, **kwargs):
        """
        Endpoint untuk membuat pengajuan izin baru dari aplikasi mobile.
        Menerima data izin dalam format JSON di body request.
        """
        # --- Langkah 1: Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengajukan izin untuk siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Ambil dan Validasi Data dari Body Request ---
            data = json.loads(request.httprequest.data)
            
            keperluan = data.get('keperluan')
            tgl_ijin = data.get('tgl_ijin') # Format diharapkan: 'YYYY-MM-DD HH:MM:SS'
            tgl_kembali = data.get('tgl_kembali')
            penjemput = data.get('penjemput')

            if not all([keperluan, tgl_ijin, tgl_kembali, penjemput]):
                return Response(json.dumps({'success': False, 'error': 'Semua field (keperluan, tgl_ijin, tgl_kembali, penjemput) wajib diisi.'}),
                                content_type='application/json', status=400) # 400 Bad Request

            # --- Langkah 3: Siapkan dan Buat Record Baru di Odoo ---
            vals = {
                'siswa_id': siswa_id,
                'keperluan': keperluan,
                'tgl_ijin': tgl_ijin,
                'tgl_kembali': tgl_kembali,
                'penjemput': penjemput,
                'state': 'Draft', # Atur status awal menjadi 'pengajuan'
                # Tambahkan field lain jika ada nilai default yang perlu diisi
            }
            
            izin_baru = request.env['cdn.perijinan'].create(vals)

            # --- Langkah 4: Kembalikan Response Sukses ---
            response_data = {
                'success': True,
                'message': 'Pengajuan izin berhasil dibuat.',
                'data': {
                    'id': izin_baru.id,
                    'name': izin_baru.name, # Nomor pengajuan izin
                    'state': izin_baru.state
                }
            }
            # Status 201 Created adalah status yang tepat untuk response POST yang berhasil membuat data baru
            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=201)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
        
    @http.route(API_URL + '/siswa/<int:siswa_id>/perizinan', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_perizinan(self, siswa_id, page=1, limit=10, **kwargs):
        """
        Endpoint untuk mengambil riwayat pengajuan izin siswa
        dengan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 10

            # Domain dasar: hanya izin milik siswa ini
            domain = [('siswa_id', '=', siswa_id)]

            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['cdn.perijinan'].search_count(domain)
            offset = (page - 1) * limit

            # Field yang ingin kita kembalikan ke aplikasi
            fields_to_read = [
                'id',
                'name',       # Nomor Izin
                'tgl_ijin',
                'tgl_kembali',
                'keperluan',
                'state',
            ]

            perizinan = request.env['cdn.perijinan'].search_read(
                domain,
                fields=fields_to_read,
                limit=limit,
                offset=offset,
                order='tgl_ijin desc, id desc'
            )

            # --- Langkah 4: Siapkan Response JSON ---
            response_data = {
                'success': True,
                'data': perizinan,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
