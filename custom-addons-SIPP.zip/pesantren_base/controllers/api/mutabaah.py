# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiMutabaah(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Mutabaah
    """

    @http.route(API_URL + '/siswa/<int:siswa_id>/mutabaah', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_mutabaah(self, siswa_id, page=1, limit=7, **kwargs):
        """
        Endpoint untuk mengambil riwayat mutabaah harian siswa, lengkap
        dengan rincian aktivitasnya dan menggunakan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit) # Ambil data per 7 hari (seminggu)
            except (ValueError, TypeError):
                page = 1
                limit = 7

            domain = [('siswa_id', '=', siswa_id)]

            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['cdn.mutabaah_harian'].search_count(domain)
            offset = (page - 1) * limit

            mutabaah_harian_records = request.env['cdn.mutabaah_harian'].search(
                domain,
                limit=limit,
                offset=offset,
                order='tgl desc, id desc'
            )

            # --- Langkah 4: Siapkan Response JSON yang Rapi ---
            hasil_akhir = []
            for record in mutabaah_harian_records:
                rincian_aktivitas = []
                for line in record.mutabaah_lines:
                    rincian_aktivitas.append({
                        'kategori': line.kategori_id.name,
                        'aktivitas': line.name.name,
                        'dilakukan': line.is_sudah,
                        'skor': line.skor,
                        'keterangan': line.keterangan,
                    })
                
                hasil_akhir.append({
                    'id': record.id,
                    'no_referensi': record.name,
                    'tanggal': record.tgl,
                    'sesi': record.sesi_id.name,
                    'total_skor': record.total_skor_display,
                    'status': record.state,
                    'rincian': rincian_aktivitas
                })

            response_data = {
                'success': True,
                'data': hasil_akhir,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)


