# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiTagihan(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Tagihan
    """

    @http.route(API_URL + '/siswa/<int:siswa_id>/tagihan', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_tagihan(self, siswa_id, status='semua', page=1, limit=10, **kwargs):
        """
        Endpoint untuk mengambil riwayat tagihan siswa dengan filter dan pagination.
        Parameter:
        - status: 'semua', 'lunas', 'belum_lunas'
        - page: halaman ke berapa
        - limit: berapa data per halaman
        """
        # --- Langkah 1: Validasi Keamanan  ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            # Konversi page dan limit ke integer, antisipasi input salah
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 10

            # Domain dasar: hanya tagihan milik siswa ini yang sudah di-post
            domain = [('siswa_id', '=', siswa_id), ('state', '=', 'posted')]

            # Tambahkan filter status berdasarkan parameter URL
            if status == 'lunas':
                domain.append(('payment_state', '=', 'paid'))
            elif status == 'belum_lunas':
                domain.append(('payment_state', 'in', ['not_paid', 'partial']))
            # Jika status='semua', tidak perlu tambah apa-apa

            # --- Langkah 3: Ambil Data dengan Pagination ---
            # Hitung total record yang cocok dengan filter, sebelum di-limit
            total_records = request.env['account.move'].search_count(domain)
            
            # Hitung offset (mulai dari record ke berapa)
            offset = (page - 1) * limit

            # Field yang ingin kita kembalikan ke aplikasi
            fields_to_read = [
                'id', 'name', 'invoice_date', 'amount_total_signed', 
                'amount_residual_signed', 'payment_state'
            ]

            # Lakukan pencarian dengan limit, offset, dan urutan
            invoices = request.env['account.move'].search_read(
                domain,
                fields=fields_to_read,
                limit=limit,
                offset=offset,
                order='invoice_date desc'
            )

            # --- Langkah 4: Siapkan Response JSON ---
            response_data = {
                'success': True,
                'data': invoices,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str), # default=str untuk handle tanggal
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
