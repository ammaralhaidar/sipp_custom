# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiTahfidz(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Tahfidz
    """

    @http.route(API_URL + '/siswa/<int:siswa_id>/tahfidz', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_tahfidz(self, siswa_id, page=1, limit=15, **kwargs):
        """
        Endpoint untuk mengambil riwayat setoran tahfidz siswa
        dengan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 15

            domain = [('siswa_id', '=', siswa_id)]

            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['cdn.tahfidz_quran'].search_count(domain)
            offset = (page - 1) * limit

            # Field yang ingin kita kembalikan, termasuk nama dari relasi (dot notation)
            fields_to_read = [
                'tanggal',
                'surah_id',     # Akan mengembalikan [ID, "Nama Surah"]
                'ayat_awal',    # Akan mengembalikan [ID, "Nomor Ayat Awal"]
                'ayat_akhir',   # Akan mengembalikan [ID, "Nomor Ayat Akhir"]
                'page_awal',
                'page_akhir',
                'jml_baris',
                'nilai_id',     # Akan mengembalikan [ID, "Nama Penilaian"]
                'ustadz_id',    # Akan mengembalikan [ID, "Nama Ustadz"]
                'keterangan',
                'state',
            ]

            setoran_tahfidz = request.env['cdn.tahfidz_quran'].search_read(
                domain,
                fields=fields_to_read,
                limit=limit,
                offset=offset,
                order='tanggal desc, id desc'
            )

            # --- Langkah 4: Siapkan Response JSON ---
            response_data = {
                'success': True,
                'data': setoran_tahfidz,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
