# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiSiswa(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Siswa (Profil, Pilih Anak).
    """

    @http.route(API_URL + '/orangtua/anak', auth='user', type='http', methods=['GET'], website=False)
    def get_daftar_anak(self, **kwargs):
        """
        Endpoint untuk mengambil daftar ringkas semua anak yang terhubung
        dengan akun orang tua yang sedang login.
        """
        try:
            logged_in_partner_id = request.env.user.partner_id.id
            Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
            if not Orangtua:
                return Response(json.dumps({'success': False, 'error': 'Profil Orang Tua tidak ditemukan'}),
                                content_type='application/json', status=404)

            # Field yang dibutuhkan untuk daftar, tanpa gambar
            fields_to_read = ['name', 'nis', 'ruang_kelas_id']
            
            # Kita gunakan search_read untuk konsistensi dan keamanan
            anak_anak_raw = request.env['cdn.siswa'].search_read(
                [('orangtua_id', '=', Orangtua.id)],
                fields=fields_to_read
            )

            # Proses data agar lebih ramah untuk mobile app
            for anak in anak_anak_raw:
                if anak.get('ruang_kelas_id'):
                    anak['kelas'] = anak['ruang_kelas_id'][1]
                else:
                    anak['kelas'] = 'Belum ada kelas'
                del anak['ruang_kelas_id']

            return Response(json.dumps({'success': True, 'data': anak_anak_raw}, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)

    @http.route(API_URL + '/siswa/<int:siswa_id>/profil', auth='user', type='http', methods=['GET'], website=False)
    def get_profil_siswa(self, siswa_id, **kwargs):
        """
        Endpoint untuk mengambil data profil lengkap dari satu siswa spesifik.
        """
        # --- Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Ambil Data Lengkap Siswa menggunakan search_read ---
            # search_read adalah cara terbaik untuk mengambil data relasi dengan aman
            fields_to_read = [
                'name', 'nis', 'nisn', 'tmp_lahir', 'tgl_lahir', 'jns_kelamin', 
                'ayah_nama', 'ibu_nama', 'wali_nama', 'tahunajaran_id', 
                'ruang_kelas_id', 'jenjang', 'tingkat', 
                'musyrif_id', 'kamar_id', 'halaqoh_id', 'penanggung_jawab_id',

            ]
            
            profil_siswa = Siswa.search_read([('id', '=', siswa_id)], fields=fields_to_read)[0]

            return Response(json.dumps({'success': True, 'data': profil_siswa}, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
        
    
    @http.route(API_URL + '/siswa/<int:siswa_id>/avatar', auth='user', type='http', methods=['GET'], website=False)
    def get_siswa_avatar(self, siswa_id, **kwargs):
        """
        Endpoint khusus untuk mengambil data gambar (avatar) siswa.
        """
        # Validasi keamanan tetap diperlukan
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response("Siswa tidak ditemukan", status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response("Akses ditolak", status=403)

        # Mengambil data gambar dan mengirimkannya sebagai response gambar
        if Siswa.avatar_128:
            image_data = base64.b64decode(Siswa.avatar_128)
            return Response(image_data, content_type='image/png', status=200)
        else:
            # Jika tidak ada gambar, bisa kembalikan gambar default atau 404
            return Response("Avatar tidak ditemukan", status=404)
