# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiUangsaku(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Uang Saku
    """

    @http.route(API_URL + '/siswa/<int:siswa_id>/uang_saku', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_uang_saku(self, siswa_id, page=1, limit=20, **kwargs):
        """
        Endpoint untuk mengambil riwayat transaksi uang saku siswa (masuk/keluar)
        dengan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data ---
        # Pola ini sama persis dengan endpoint sebelumnya
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 20

            # Domain: Cari transaksi uang saku berdasarkan partner_id siswa
            # Berdasarkan kode `webservices.py` Anda, relasi `siswa_id` di `cdn.uang_saku` mengarah ke partner.
            domain = [('siswa_id', '=', Siswa.partner_id.id)]

            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['cdn.uang_saku'].search_count(domain)
            offset = (page - 1) * limit

            # Field yang ingin kita kembalikan ke aplikasi
            fields_to_read = [
                'tgl_transaksi',
                'jns_transaksi',
                'amount_in',
                'amount_out',
                'keterangan',
                'state',
            ]

            transaksi = request.env['cdn.uang_saku'].search_read(
                domain,
                fields=fields_to_read,
                limit=limit,
                offset=offset,
                order='tgl_transaksi desc, id desc'
            )

            # --- Langkah 4: Siapkan Response JSON ---
            response_data = {
                'success': True,
                'data': transaksi,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
