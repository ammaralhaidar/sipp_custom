# -*- coding: utf-8 -*-
import json
import math
import base64
from odoo import http
from odoo.http import request, Response

# Mendefinisikan URL dasar untuk semua endpoint di file ini
API_URL = '/api/v1'

class ApiAktivitas(http.Controller):
    """
    Controller ini khusus menangani semua proses yang berhubungan dengan
    Aktivitas (Pelanggaran, Kesehatan, Prestasi).
    """
    
    @http.route(API_URL + '/siswa/<int:siswa_id>/pelanggaran', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_pelanggaran(self, siswa_id, page=1, limit=10, **kwargs):
        """
        Endpoint untuk mengambil riwayat pelanggaran siswa
        dengan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])

        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 10

            # Domain: Cari pelanggaran milik siswa ini yang statusnya sudah disetujui
            domain = [('siswa_id', '=', siswa_id), ('state', '=', 'approved')]

            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['cdn.pelanggaran'].search_count(domain)
            offset = (page - 1) * limit

            # Field yang ingin kita tampilkan di aplikasi mobile
            fields_to_read = [
                'tgl_pelanggaran',
                'pelanggaran_id',   # Akan mengembalikan [ID, "Nama Pelanggaran"]
                'kategori',
                'poin',
                'deskripsi',
                'tindakan_id',      # Akan mengembalikan [ID, "Nama Tindakan"]
                'diperiksa_oleh',   # Akan mengembalikan [ID, "Nama Pemeriksa"]
                'catatan_ka_asrama',
            ]

            riwayat_pelanggaran = request.env['cdn.pelanggaran'].search_read(
                domain,
                fields=fields_to_read,
                limit=limit,
                offset=offset,
                order='tgl_pelanggaran desc, id desc'
            )

            # --- Langkah 4: Siapkan Response JSON ---
            response_data = {
                'success': True,
                'data': riwayat_pelanggaran,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
    
    @http.route(API_URL + '/siswa/<int:siswa_id>/kesehatan', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_kesehatan(self, siswa_id, page=1, limit=10, **kwargs):
        """
        Endpoint untuk mengambil riwayat kesehatan siswa
        dengan pagination.
        """
        # --- Langkah 1: Validasi Keamanan & Data Siswa ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)

        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Langkah 2: Persiapkan Filter (Domain) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 10

            # Domain: Cari catatan kesehatan milik siswa ini
            domain = [('siswa_id', '=', siswa_id)]

            # --- Langkah 3: Ambil Data dengan Pagination ---
            total_records = request.env['cdn.kesehatan'].search_count(domain)
            offset = (page - 1) * limit

            # Field yang ingin kita tampilkan di aplikasi mobile
            fields_to_read = [
                'tgl_diperiksa',
                'keluhan',
                'diperiksa_oleh',
                'diagnosa',
                'obat',
                'catatan',
                'lokasi_rawat',
                'tgl_selesai',
                'state',
            ]

            riwayat_kesehatan = request.env['cdn.kesehatan'].search_read(
                domain,
                fields=fields_to_read,
                limit=limit,
                offset=offset,
                order='tgl_diperiksa desc, id desc'
            )

            # --- Langkah 4: Siapkan Response JSON ---
            response_data = {
                'success': True,
                'data': riwayat_kesehatan,
                'pagination': {
                    'page': page,
                    'limit': limit,
                    'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }

            return Response(json.dumps(response_data, default=str),
                            content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
    
    @http.route(API_URL + '/siswa/<int:siswa_id>/prestasi', auth='user', type='http', methods=['GET'], website=False)
    def get_riwayat_prestasi(self, siswa_id, page=1, limit=10, **kwargs):
        """
        Endpoint untuk mengambil riwayat prestasi siswa
        dengan pagination. (Versi dengan foto_url)
        """
        # --- Validasi Keamanan & Data Siswa (tetap sama) ---
        Siswa = request.env['cdn.siswa'].search([('id', '=', siswa_id)])
        if not Siswa:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)
        logged_in_partner_id = request.env.user.partner_id.id
        Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])
        if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
            return Response(json.dumps({'success': False, 'error': 'Anda tidak berhak mengakses data siswa ini'}),
                            content_type='application/json', status=403)

        try:
            # --- Persiapkan Filter & Pagination (tetap sama) ---
            try:
                page = int(page)
                limit = int(limit)
            except (ValueError, TypeError):
                page = 1
                limit = 10
            domain = [('siswa_id', '=', siswa_id)]
            total_records = request.env['cdn.prestasi_siswa'].search_count(domain)
            offset = (page - 1) * limit

            # --- Ambil data dan bangun response secara manual ---
            riwayat_prestasi_records = request.env['cdn.prestasi_siswa'].search(
                domain, limit=limit, offset=offset, order='tgl_prestasi desc, id desc'
            )

            data_prestasi = []
            for prestasi in riwayat_prestasi_records:
                data_prestasi.append({
                    'id': prestasi.id,
                    'tgl_prestasi': prestasi.tgl_prestasi,
                    'tingkat_prestasi': prestasi.tingkat_prestasi,
                    'jenis_prestasi': prestasi.jns_prestasi_id.name,
                    'juara': prestasi.joara,
                    'keterangan': prestasi.keterangan,
                    # Tambahkan foto_url HANYA jika ada foto
                    'foto_url': f'/api/v1/prestasi/{prestasi.id}/foto' if prestasi.foto else None,
                })

            response_data = {
                'success': True,
                'data': data_prestasi,
                'pagination': {
                    'page': page, 'limit': limit, 'total_records': total_records,
                    'total_pages': math.ceil(total_records / limit)
                }
            }
            return Response(json.dumps(response_data, default=str), content_type='application/json', status=200)

        except Exception as e:
            return Response(json.dumps({'success': False, 'error': f'Terjadi kesalahan internal: {e}'}),
                            content_type='application/json', status=500)
    
    @http.route(API_URL + '/prestasi/<int:prestasi_id>/foto', auth='user', type='http', methods=['GET'], website=False)
    def get_prestasi_foto(self, prestasi_id, **kwargs):
        """
        Endpoint ini hanya mengembalikan data biner (gambar) dari
        satu record prestasi.
        """
        try:
            # Cari record prestasi
            Prestasi = request.env['cdn.prestasi_siswa'].search([('id', '=', prestasi_id)])
            if not Prestasi or not Prestasi.foto:
                return Response("Foto tidak ditemukan", status=404)

            # Validasi keamanan: pastikan orang tua yang login berhak melihat foto ini
            # dengan mengecek siapa pemilik record prestasi ini
            Siswa = Prestasi.siswa_id
            logged_in_partner_id = request.env.user.partner_id.id
            Orangtua = request.env['cdn.orangtua'].search([('partner_id', '=', logged_in_partner_id)])

            if not Orangtua or Siswa.orangtua_id.id != Orangtua.id:
                return Response("Akses ditolak", status=403)

            # Decode data base64 dari field Binary Odoo
            image_data = base64.b64decode(Prestasi.foto)

            # Kembalikan sebagai response gambar
            return Response(image_data, content_type='image/jpeg', status=200)

        except Exception as e:
            return Response(f"Error: {e}", status=500)    