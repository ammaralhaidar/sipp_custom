# -*- coding: utf-8 -*-
import werkzeug
import json
from odoo import http
from odoo.http import request, Response

class CalonSiswaApiController(http.Controller):

    def _validate_token(self):
        """Fungsi helper untuk validasi token."""
        token_str = request.httprequest.headers.get('token')
        if not token_str:
            return None
        
        token = request.env['api.token'].sudo().search([
            ('token', '=', token_str),
            ('kadaluwarsa', '>', fields.Datetime.now())
        ], limit=1)

        if not token:
            return None
        
        return token.user_id

    @http.route('/api/v1/semua_calon_siswa', auth='none', type='http', methods=['GET'], csrf=False)
    def api_login(self, **kw):
        params = request.jsonrequest
        login = params.get('login')
        password = params.get('password')
        db = params.get('db')

        uid = request.session.authenticate(db, login, password)
        if not uid:
            # Jika login gagal
            return {'success': False, 'error': 'Login atau Password salah'}

        # Jika login berhasil, buatkan token
        Token = request.env['api.token'].sudo() # .sudo() agar bisa dijalankan oleh sistem
        token_baru = Token._generate(uid)

        # Kembalikan token ke aplikasi mobile
        return {
            'success': True,
            'data': {
                'uid': uid,
                'token': token_baru.token,
                'nama': token_baru.user_id.name,
                'email': token_baru.user_id.email,
            }
        }


    @http.route('/api/v1/semua_calon_siswa', auth='none', type='http', methods=['GET'])
    def get_semua_calon_siswa(self, **kw):
        """
        Endpoint untuk mengambil daftar semua calon siswa.
        Sekarang diamankan dengan token.
        """
        # Langkah 1: Validasi token
        user_id = self._validate_token()
        if not user_id:
            # Jika tidak valid, kembalikan error 401 Unauthorized
            return Response(json.dumps({'success': False, 'error': 'Token tidak valid atau kadaluwarsa'}),
                            content_type='application/json', status=401)
        
        # Langkah 2: Jika token valid, jalankan query sebagai user tersebut
        # Ingat, nama model Anda adalah 'calon.siswa'
        semua_siswa = request.env['calon.siswa'].with_user(user_id).search_read(
            [], fields=['name', 'nis', 'state']
        )
        
        # Langkah 3: Kembalikan data
        return Response(json.dumps({'success': True, 'data': semua_siswa}),
                        content_type='application/json', status=200)

    @http.route('/api/v1/calon_siswa/<int:siswa_id>', auth='none', type='http', methods=['GET'])
    def get_satu_calon_siswa(self, siswa_id, **kw):
        """
        Endpoint untuk mengambil detail satu calon siswa berdasarkan ID-nya.
        Sekarang diamankan dengan token.
        """
        # Langkah 1: Validasi token
        user_id = self._validate_token()
        if not user_id:
            return Response(json.dumps({'success': False, 'error': 'Token tidak valid atau kadaluwarsa'}),
                            content_type='application/json', status=401)

        # Langkah 2: Jika token valid, cari data
        domain = [('id', '=', siswa_id)]
        # Ingat, nama model Anda adalah 'calon.siswa'
        siswa = request.env['calon.siswa'].with_user(user_id).search_read(domain)

        # Langkah 3: Kembalikan data
        if siswa:
            return Response(json.dumps({'success': True, 'data': siswa[0]}),
                            content_type='application/json', status=200)
        else:
            return Response(json.dumps({'success': False, 'error': 'Siswa tidak ditemukan'}),
                            content_type='application/json', status=404)