# -*- coding: utf-8 -*-
# from odoo import http


# class PesantrenCalonSiswa(http.Controller):
#     @http.route('/pesantren_calon_siswa/pesantren_calon_siswa', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/pesantren_calon_siswa/pesantren_calon_siswa/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('pesantren_calon_siswa.listing', {
#             'root': '/pesantren_calon_siswa/pesantren_calon_siswa',
#             'objects': http.request.env['pesantren_calon_siswa.pesantren_calon_siswa'].search([]),
#         })

#     @http.route('/pesantren_calon_siswa/pesantren_calon_siswa/objects/<model("pesantren_calon_siswa.pesantren_calon_siswa"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('pesantren_calon_siswa.object', {
#             'object': obj
#         })
