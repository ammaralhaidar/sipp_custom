# -*- coding: utf-8 -*-
{
    'name': "Modul Pesantren Calon Siswa", # Nama modul yang akan muncul di Odoo
    
    'summary': """
        Modul untuk manajemen calon siswa baru, mulai dari pendaftaran,
        pembuatan NIS, hingga tagihan daftar ulang.""",

    'description': """
        Modul ini menangani alur penerimaan siswa baru di IBS Al Hamra.
    """,

    'author': "Ammar Al Haidar", "Gemini Pro"
    'website': "https://www.ibsalhamra.sch.id",

    'category': 'Education',
    'version': '16.0.1.0.0',

    # Modul lain yang kita butuhkan agar modul ini berjalan
    'depends': ['base', 'account', 'mail', 'pesantren_base'],

    # File data yang akan dimuat oleh Odoo
    'data': [
        'security/ir.model.access.csv',
        #actions
        # 'actions/calon_siswa_server_actions.xml',
        #data
        'views/calon_siswa_views.xml',
        'views/biaya_daftar_ulang_views.xml',
        # 'views/tagihan_calon_siswa.xml',
        'views/tagihan_calon.xml',
    ],
    
    'installable': True,
    'application': True, # Menjadikan modul ini sebagai aplikasi di menu utama Odoo
    'auto_install': False,
}