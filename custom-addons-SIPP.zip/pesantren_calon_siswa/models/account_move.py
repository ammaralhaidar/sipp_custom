# -*- coding: utf-8 -*-

from odoo import models, fields

class AccountMove(models.Model):
    # Inherit: Menambahkan fungsionalitas ke model yang sudah ada
    _inherit = 'account.move'

    # Field baru untuk menyimpan link ke calon siswa
    calon_siswa_id = fields.Many2one(
        'calon.siswa', 
        string='Calon Siswa',
        readonly=True,
        copy=False # Jangan duplikasi link ini jika invoice dicopy
    )

    # Field ini secara otomatis mengambil nilai dari:
    # self.calon_siswa_id.biaya_id
    jenis_pendaftaran_id = fields.Many2one(
        related='calon_siswa_id.biaya_id',
        string='Jenis Pendaftaran',
        readonly=True
    )