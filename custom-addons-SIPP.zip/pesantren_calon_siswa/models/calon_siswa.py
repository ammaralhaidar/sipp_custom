# -*- coding: utf-8 -*-

from odoo.exceptions import ValidationError
# from odoo.exceptions import UserError
from odoo import models, fields, api

class CalonSiswa(models.Model):
    _name = 'calon.siswa'
    _description = 'Pendaftaran Calon Siswa'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    _inherits = {'res.partner': 'partner_id'}

    partner_id = fields.Many2one('res.partner', 'Partner', required=True, ondelete="cascade")
    
    # === GRUP FIELD DATA DIRI ===
    jenis_kelamin = fields.Selection([
        ('laki-laki', 'Laki-laki')
    ], string='Jenis Kelamin', required=True)
    tempat_lahir = fields.Char(string='Tempat Lahir')
    tanggal_lahir = fields.Date(string='Tanggal Lahir') # Field khusus untuk tanggal
    asal_sekolah = fields.Char(string='Asal Sekolah')

    # === GRUP FIELD ORANG TUA ===
    nama_ayah = fields.Char(string="Nama Lengkap Ayah")
    hp_ayah = fields.Char(string="Nomor HP Ayah")
    nama_ibu = fields.Char(string="Nama Lengkap Ibu")
    hp_ibu = fields.Char(string="Nomor HP Ibu")

    # === GRUP FIELD PENDAFTARAN & KEUANGAN ===
    nis = fields.Char(string='NIS', readonly=True, copy=False, default='Belum Dibuat')

    # Field Many2one adalah penghubung ke model lain. Ini akan tampil
    # sebagai dropdown yang isinya adalah semua data dari model 'biaya.daftar.ulang'.
    biaya_id = fields.Many2one('biaya.daftar.ulang', 
                               string='Jenis Pendaftaran', 
                               required=True)

    diskon = fields.Monetary(string='Diskon (Nominal)', tracking=True)

    # Kolom ini akan kita isi dengan tagihan setelah dibuat
    invoice_id = fields.Many2one('account.move', string='Tagihan', readonly=True)
    currency_id = fields.Many2one(related='biaya_id.currency_id')

    # === GRUP FIELD STATUS ===
    state = fields.Selection([
        ('draft', 'Draft'),
        ('diterima', 'Diterima'),
        ('sudah_ditagih', 'Sudah Ditagih'),
        ('lunas', 'Lunas'),
        # ('migrated', 'Sudah Dimigrasi')
        ('mengundurkan_diri', 'Mengundurkan Diri')
    ], string='Status', default='draft', required=True, tracking=True)

    @api.model
    def create(self, vals):
        # 'vals' adalah dictionary yang berisi semua data yang diinput dari form
        # 1. Ambil ID dari biaya_id yang dipilih di form
        biaya_id = vals.get('biaya_id')
        if biaya_id:
            # 2. Cari record biaya_id tersebut untuk mendapatkan info tahun dan jenjang
            biaya_record = self.env['biaya.daftar.ulang'].browse(biaya_id)
            tahun = biaya_record.tahun
            jenjang = biaya_record.jenjang

            # 3. Format komponen NIS
            # Ambil 2 digit terakhir dari tahun (cth: 2025 -> 25)
            kode_tahun = tahun[-2:]

            # Tentukan kode jenjang
            if jenjang == 'smp':
                kode_jenjang = '01'
            elif jenjang == 'sma':
                kode_jenjang = '02'
            else: # untuk 'alih_jenjang'
                kode_jenjang = '02' 

            # 4. Cari nomor urut terakhir
            prefix_nis = kode_tahun + kode_jenjang
            # Cari semua siswa yang punya prefix NIS yang sama
            # Contoh: '2501%' akan cocok dengan '2501001', '2501002', dst.
            siswa_terakhir = self.search(
                [('nis', '=like', prefix_nis + '%')],
                order='nis desc',
                limit=1
            )

            #5. Tentukan nomor berikutnya
            if siswa_terakhir:
                #Jika ditemukan siswa sebelumnya 
                nomor_urut_lama = int(siswa_terakhir.nis[-3:])
                #nomor urut baru
                nomor_urut_baru = nomor_urut_lama + 1

            else:
                nomor_urut_baru = 1
            
            # 6. Format nomor urut menjadi 3 digit (misal: 4 -> "004")
            kode_urut = f"{nomor_urut_baru:03d}"

            # 7. Gabungkan semua komponen dan simpan ke dalam 'vals'
            vals['nis'] = prefix_nis + kode_urut
        
        # 8. Jalankan proses create Odoo yang standar dengan 'vals' yang sudah kita modifikasi
        return super(CalonSiswa, self).create(vals)

    
    def action_setuju(self):
        for rec in self:
            rec.state = 'diterima'

    def action_buat_tagihan(self):
        # Loop untuk setiap record yang dipilih (meskipun biasanya hanya satu dari form view)
        for rec in self:
            # Validasi: jangan buat tagihan jika sudah ada
            if rec.invoice_id:
                raise ValidationError("Siswa ini sudah memiliki tagihan!")
            if not rec.biaya_id:
                raise ValidationError("Jenis pendaftaran (biaya) belum ditentukan!")

            # Siapkan baris-baris tagihan (invoice lines)
            invoice_lines = []
            # Baris untuk biaya utama
            invoice_lines.append((0, 0, {
                'name': f"Biaya Daftar Ulang - {rec.biaya_id.name}",
                'quantity': 1,
                'price_unit': rec.biaya_id.harga,
            }))

            # Jika ada diskon, tambahkan sebagai baris terpisah dengan nilai negatif
            if rec.diskon > 0:
                invoice_lines.append((0, 0, {
                    'name': "Diskon Pendaftaran",
                    'quantity': 1,
                    'price_unit': -rec.diskon, # Nilai diskon dibuat negatif
                }))

            # Buat Customer Invoice di modul Akuntansi
            tagihan = self.env['account.move'].create({
                'move_type': 'out_invoice', # Tipe: Customer Invoice
                'partner_id': rec.partner_id.id,
                'invoice_date': fields.Date.today(),
                'invoice_line_ids': invoice_lines,
                'calon_siswa_id': rec.id,
            })

            # Tautkan tagihan yang baru dibuat ke calon siswa
            rec.invoice_id = tagihan.id
            # Ubah status calon siswa
            rec.state = 'sudah_ditagih'

        return True
    
    def action_mengundurkan_diri(self):
        # Loop untuk setiap record yang dipilih. walau biasanya hanya satu dari form
        for rec in self:
            # cek jika sudah ada invoice terkait
            if rec.invoice_id:
                # fungsi bawaan odoo untuk membatalkan invoice
                # mengubah status menjadi 'cancel'
                rec.invoice_id.button_cancel()
            # ubah status menjadi 'mengundurkan_diri'
            rec.state = 'mengundurkan_diri'
        return True
    
    # def action_migrasi_ke_santri(self):
    #     Siswa = self.env['cdn.siswa']
    #     IrModelData = self.env['ir.model.data']

    #     for rec in self:
    #     #validasi = cek apakah NIS sudah ada
    #         siswa_exist = Siswa.search([('nis', '=', rec.nis)], limit=1)
    #         if siswa_exist:
    #             raise UserError(f"Siswa dengan NIS '{rec.nis}' ({rec.name}) sudah ada di data utama!")
            
    #         # Siapkan data untuk membuat record cdn.santri baru
    #         # Kita hanya perlu memberikan partner_id yang sudah ada.
    #         # Mekanisme _inherits di cdn.santri akan menanganinya.
    #         siswa_vals = {
    #             'partner_id': rec.partner_id.id,
    #             'nis': rec.nis,
    #             # Tambahkan mapping field lain jika diperlukan, contoh:
    #             # 'jenis_kelamin': rec.jenis_kelamin,
    #             # 'tanggal_lahir': rec.tanggal_lahir,
    #         }
            
    #         # buat record santri baru
    #         siswa_baru = Siswa.create(siswa_vals)

    #         # Membuat External ID Custom, format: siswa_2601001
    #         xml_id = f"siswa_{rec.nis}"

    #         # Buat record di ir.model.data untuk mendaftarkan ID baru kita
    #         IrModelData.create({
    #             'name': xml_id,
    #             'module': '__export__',
    #             'model': 'cdn.santri',
    #             'res_id': siswa_baru.id,
    #         })

    #         #update status menjadi migrated
    #         rec.state = 'migrated'

    #     return True


        