# -*- coding: utf-8 -*-
import uuid
from odoo import models, fields, api
from datetime import datetime, timedelta

class ApiToken(models.Model):
    _name = 'api.token'
    _description = 'API Access Token untuk Aplikasi Mobile'

    token = fields.Char(string='Token', required=True, index=True, default=lambda self: str(uuid.uuid4()))
    user_id = fields.Many2one('res.users', string='Pengguna', required=True, ondelete='cascade')
    kadaluwarsa = fields.Datetime(string='Kadaluwarsa', required=True)

    @api.model
    def _generate(self, user_id):
        # Hapus token lama jika ada untuk user yang sama
        self.search([('user_id', '=', user_id)]).unlink()
        # Buat token baru yang berlaku selama 30 hari
        masa_berlaku = datetime.now() + timedelta(days=30)
        token_baru = self.create({
            'user_id': user_id,
            'kadaluwarsa': masa_berlaku,
        })
        return token_baru