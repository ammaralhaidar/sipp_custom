# -*- coding: utf-8 -*-

from odoo import models, fields, api

class BiayaDaftarUlang(models.Model):
    # Nama teknis model. Odoo akan membuat tabel bernama hamra_biaya_daftar_ulang
    _name = 'biaya.daftar.ulang'
    _description = 'Master Biaya Daftar Ulang Santri'
    _rec_name = 'name'

    name = fields.Char(string='Nama Paket Pendaftaran', required=True, 
                       help="Contoh: SMP Tahun Ajaran 2025/2026")

    # Field Char untuk menyimpan teks singkat, seperti tahun masuk "2025"
    tahun = fields.Char(string='Tahun Masuk', required=True,
                    help="Tahun masuk siswa, contoh: 2025. Digunakan untuk generate NIS.")
    # Field Selection berfungsi seperti dropdown / pilihan
    jenjang = fields.Selection([
        ('smp', 'SMP'),
        ('sma', 'SMA'),
        ('alih_jenjang', 'SMA (Alih Jenjang)')
    ], string='Jenjang', required=True, help="Jenjang siswa. Digunakan untuk generate NIS.")

    # Field Monetary khusus untuk menyimpan nilai uang
    harga = fields.Monetary(string='Harga Daftar Ulang', required=True)

    # Field ini wajib ada jika kita menggunakan field Monetary.
    # Secara otomatis akan mengambil mata uang default perusahaan (misal: IDR).
    currency_id = fields.Many2one('res.currency', string='Currency', 
                                  default=lambda self: self.env.company.currency_id)